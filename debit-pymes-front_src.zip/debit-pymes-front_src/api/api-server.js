/**
 * This file creates an API server based on json-server module
 * to simulate XHR call request
 * It is able to serve dynamic json responses and statics files as well
 */

const path = require('path');
const jsonServer = require('json-server');
const server = jsonServer.create();
const router = jsonServer.router(path.join(__dirname, 'db.json'));
const middlewares = jsonServer.defaults({
  static: 'api/public'
});

server.use(middlewares);
server.use(jsonServer.bodyParser);

server.use(function (req, res, next) {
  if (req.method === 'POST' || req.method === 'DELETE' || req.method === 'PUT') {
    // Converts POST to GET and move payload to query params
    // This way it will make JSON Server that it's GET request
    req.method = 'GET'
    req.query = req.body
  }
  if(req.url.endsWith('hire')){
    setTimeout(next, 5000);
  }else{
    setTimeout(next, 1000);
  }
  // Continue to JSON Server router
  // next()
})

// add this redirects before server.use(router)
server.use(jsonServer.rewriter({
  "/api/logger/log": "/api/logs",
  "/api/logger/logs": "/api/logs",
  "/api/logger/logs/:id": "/api/logs/:id",
  "/api/security/tokens": "/api/tokens",
  "/api/security/tokens/refresh": "/api/refresh",
  "/api/v1/persons/:id/:id/carousel": "/api/carousel",
  "/api/v1/persons/:id/:id/beneficiaries?*": "/api/beneficiaries",
  "/api/v1/persons/:id/:id/customization": "/api/customization",
  "/api/v1/persons/getIndPeticion": "/api/getIndPeticion",
  "/api/v1/persons/getSign": "/api/getSign",
  "/api/v1/persons/cancelExp": "/api/cancelExp",
  "/api/v1/persons/hire/*": "/api/hire",
  "/api/v1/persons/getDocument": "/api/getDocument",
  "/api/v1/persons/validarCufed": "/api/validarCufed",
}));

server.get('/api/alive', function (req, res, next) {
  res.sendStatus(6000);
});

let num = 0;
server.post('/api/security/tokens/refresh', function (req, res, next) {
  setTimeout(res.json({
    "token": `faketoken-${++num}`,
    "expirationRelative": "120000"
  }), 30000);
});

// don't move this serve.use(router) before server.<verbs>()
server.use('/api', router);

server.listen(3000, function () {
  console.log('\x1b[36m%s\x1b[0m\x1b[46m%s\x1b[0m', '\\{^_^}/ Hi! Welcome to ', 'Darwin fake API');
  console.log('\x1b[90m%s\x1b[0m', 'Remember you can modify this fake API in api-serve.js file\n\r');
  console.log('\x1b[36m%s\x1b[0m', 'JSON Server is running on port 3000...')
})
