// Santander logo image path
export const LOGO_URL = '../../assets/images/logos/santander_logo_white.png';
// Large card image path
export const CARD_IMAGE = '../../../../../assets/images/icons/debit_card.png';
// Small card image path
export const CARD_IMAGE_SMALL = '../../../../../assets/images/icons/debit_card_small.png';
// Error Icon path
export const ERROR_ICON = '../../../../../assets/images/icons/error-i.svg';