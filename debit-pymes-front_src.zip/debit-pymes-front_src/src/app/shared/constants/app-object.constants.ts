// Sessión storage object
export const APP_OBJECT: any = {
  idExpedient: '',
	language: ' es_ES',
	shippingType: '',
	office: {
		officeId: '',
	  officeName: '',
	  officeLocation: '',
		officeAddress: {
		  address: '',
			addressType: '',
		  addressFormat: '',
		  order: ''
	  },
		officeTeller: '',
	},
	company: {
	  personType: '',
		personId: '',
	  companyDocument: '',
	  typeCompanyDocument: '',
	  companyName: '',
		companyUsualAddress: {
			address: '',
			addressType: '',
		  addressFormat: '',
		  order: ''
		},
		companyShippingAddress:	{
		  address: '',
			addressType: '',
		  addressFormat: '',
		  order: ''
		},
		companyNameCard: ''
	},
	localContracts: {
		productId: '',
		subProductId: '',
		productDesc: '',
		standarRef: '',
		economicCondition: '',
		typeCard: '',
		brandCard: '',
		estampacionCode: '',
		localContract: {
			contractId: '',
		},
		partenonContract: {
		  companyId: '',
			branchId: '',
			productId: '',
			contractId: ''
		},
		descriptionContract: '',
		partenonPAN: {
		  companyId: '',
			branchId: '',
			productId: '',
			contractId: ''
		}
	},
	representatives: [
		{
			name: '',
			personType: '',
			personId: '',
			document: '',
			typeDocument: '',
			typeAttorney : '',
			sex: '',
		  usualAddress:	{
			  address: '',
				addressType: '',
			  addressFormat: '',
			  order: ''
		  },
		  shippingAddress: {
			  address: '',
			  addressType: '',
			  addressFormat: '',
			  order: ''
		  },
			preferredPhone:	{
				number: '',
				type: '',
				order: ''
			},
			cesPhone:	{
			  number: '',
				type: '',
				order: ''
			},
		  ces: '',
			preferredEmail:	{
				email: '',
				type: ''
			},
			personNameCard: ''
	  }
	],
	documents: [
		{
			gnId: '',
			documentType: '',
			mandatory: '',
			signers: [
				{
					personType: '',
					personId: '',
          signatureStatus: '',
          requestSignature: '',
          signatureId: ''
				}
			]
		}
	]
}
