// angular imports
import { Component, OnInit, Inject } from '@angular/core';
import { Router } from '@angular/router';

// angular materials imports
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.css']
})
export class ModalComponent implements OnInit {
  public title!: string;
  public bodyText!: string;
  public buttons = false;
  public button = false;
  public route!: string;
  public errorDesc?: string;

  constructor(
    public router: Router,
    public dialogRef: MatDialogRef<ModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    dialogRef.disableClose = true;
  }

  /**
   * Initializes the modal info
   */
  ngOnInit() {
    this.title = this.data.title;
    this.bodyText = this.data.bodyText;
    this.buttons = this.data.buttons;
    this.button = this.data.button;
    this.route = this.data.route;
    this.errorDesc = this.data.errorDesc || '';
  }

  /**
   * Close the modal window
   */
  public closeModal() {
    this.dialogRef.close();
  }

  /**
   * Go to the route in the input variable
   */
  public goTo() {
    // Navigate to the route
    this.router.navigate([this.route]);
    // Close the modal window
    this.dialogRef.close();
  }
}
