// angular imports
import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

// application services imports
import { SecurityService } from '@ng-darwin/security';
import { SessionStorageService } from '../../services/session-storage.service';
import { UtilsService } from '../../services/utils.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  @Input() logo!: string;
  @Input() branchUser!: string;
  @Input() rightMenu!: boolean

  public idExpedient: any;
  public appObject: any;

  constructor(
    public securityService: SecurityService,
    public sessionStorageService: SessionStorageService,
    public router: Router,
    public utilsService: UtilsService
  ) { }

  ngOnInit() {
  }

  /**
   * Logout in the application
   */
  closeWindow() {
    this.appObject = this.sessionStorageService.getSessionStorage();
    this.idExpedient = this.appObject.idExpedient;
    this.utilsService.cancelExpedient(this.idExpedient);
  }
}
