// angular imports
import { Component, OnInit } from '@angular/core';

// shared components imports
import { LOGO_URL } from '../../constants/utils.constants';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {
  // Image variable
  public logoURL: string = LOGO_URL;

  constructor() { }

  ngOnInit() { }
}