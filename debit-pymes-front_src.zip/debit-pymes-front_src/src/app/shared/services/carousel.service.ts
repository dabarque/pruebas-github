// angular imports
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// application services import
import { RestService } from '../../shared/services/rest.service';

@Injectable({
  providedIn: 'root'
})
export class CarouselService {

  constructor (private readonly http: HttpClient, private readonly rest: RestService) {
  }

  /**
   * Get the observable for the carousel service
   *
   * @param {string} personId The user id
   * @param {string} personType The user type
   * @returns {Observable<any>} The service observable
   */
  fetchCarousel (personId: string, personType: string): Observable<any> {
    const request$ = this.http.get<any>(this.rest.getEndpointUrl(`carousel`, {personType, personId}));
    return request$;
  }
}