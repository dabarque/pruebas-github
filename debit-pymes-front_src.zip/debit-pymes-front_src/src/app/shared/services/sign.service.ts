// angular imports
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// application services import
import { RestService } from '../../shared/services/rest.service';

@Injectable({
    providedIn: 'root'
})
export class SignService {

    constructor(private readonly http: HttpClient, private readonly rest: RestService) {
    }

    /**
     * Get the observable for the carousel service
     *
     * @param {string} idExpedient The expedient id
     * @param {string} signer The signer name
     * @param {string} name The name
     * @param {string} document The document Id
     * @param {string} language The language
     * @returns {Observable<any>} The service observable
     */
    fetchSignUrl (
        idExpedient: string,
        signer: string,
        name: string,
        document: string,
        language: string,
        typeS: string
    ): Observable<any> {
        const request$ = this.http.get<any>(encodeURI(this.rest.getEndpointUrl(`getSign`, { idExpedient, signer, name, document, language, typeS })));
        return request$;
    }
}