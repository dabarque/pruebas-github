// angular imports
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// application services imports
import { SessionStorageService } from '../../shared/services/session-storage.service';
import { RestService } from '../../shared/services/rest.service';

@Injectable({
  providedIn: 'root'
})
export class CustomizationService {

  constructor (
    private readonly http: HttpClient,
    private readonly rest: RestService,
    private readonly sessionStorageService: SessionStorageService
  ) { }

  /**
   * Get the observable for the carousel service
   *
   * @returns {Observable<any>} The service observable
   */
  fetchCustomizationInfo (personId: string, personType: string): Observable<any> {
    const request$ = this.http.post<any>(this.rest.getEndpointUrl(`customization`, {personType, personId}), this.requestJson());
    return request$;
  }

  /**
   * Truncate the beneficiary name to 21 positions
   *
   * @param {string} name Beneficiary name param
   * @returns {string} Beneficiary name trucanted
   */
  formatBeneficiaryName (name: string): string {
    // if the name has more than 21 characters, return the initial of the name and surnames
    if (name.length > 21){
      name = `${name.charAt(0)}.${name.substring(name.indexOf(' ')+1)}`;
    }
    // If the name still has more than 21 characters, trim characters to the right
    while (name.length > 21){
      name = name.slice(0, -1);
    }
    return name;
  }

  /**
   * Truncate the forth stamping line to 21 positions
   *
   * @param {string} stampingLine Forth stamping line param
   * @returns {string} Forth stamping line truncated
   */
  formatForthStampingLine (stampingLine: string): string {
    // If the stamping line has more than 21 characters, trim characters to the right
    while (stampingLine.length > 21){
      stampingLine = stampingLine.slice(0, -1);
    }
    return stampingLine;
  }

  /**
   * Get the Json for the customization service request
   */
  requestJson (): {} {
    // Get the sessionStorage object
    const jsonObject: any = this.sessionStorageService.getSessionStorage();
    // create a object with sessionStorage data
    const jsonServiceRequestObject = {
      officeId: jsonObject.office ? jsonObject.office.officeId: '',
      representatives: jsonObject.representatives
    }
    return jsonServiceRequestObject;
  }
}