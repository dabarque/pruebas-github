// angular imports
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// application services import
import { RestService } from '../../shared/services/rest.service';

@Injectable({
    providedIn: 'root'
})
export class SignStatusService {

    constructor(private readonly http: HttpClient, private readonly rest: RestService) {
    }

    /**
     * Get the observable for the carousel service
     *
     * @param {string} signatureId The expedient id
     * @returns {Observable<any>} The service observable
     */
    fetchSignStatus (
        signatureId: string
    ): Observable<any> {
        const request$ = this.http.get<any>(this.rest.getEndpointUrl(`getIndPeticion`, { signatureId }));
        return request$;
    }
}