// angular imports
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SessionStorageService {

  constructor () {
  }

  /**
   * Get the sessionStorage object
   *
   * @returns {any[]} return the sessionStorage object
   */
  getSessionStorage (): any[] {
    const SESSION_OBJECT: any[] = JSON.parse(sessionStorage.getItem('appObject') || '{}');
    return SESSION_OBJECT;
  }

  /**
   * Set the sessionStorage object
   *
   * @param {any[]} appObject the sessionStorage object
   */
  setSessionStorage (appObject: any[]): void {
    sessionStorage.setItem('appObject', JSON.stringify(appObject));
  }

  /**
   * Delete the sessionStorage object
   */
  deleteSessionStorage (): void {
    sessionStorage.removeItem('appObject');
  }
}