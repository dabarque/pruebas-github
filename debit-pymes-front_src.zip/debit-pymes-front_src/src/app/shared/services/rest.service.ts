// angular imports
import { Injectable } from '@angular/core';
import { ConfigService } from '@ng-darwin/config';

@Injectable({
  providedIn: 'root'
})
export class RestService {
  public concatCharacter = '?';

  constructor(private readonly configService: ConfigService){}

  /**
   * Get the api Url
   *
   * @param {string} endpoint The endpoint name
   * @returns the api url
   */
  public getApiUrl (endpoint: string) {
    const restProperties: any = this.configService.config.app.rest;
    const { host, port, ssl, basePath } = restProperties;
    const protocol: string = ssl ? 'https' : 'http';
    const basePathUrl: string = basePath ? `${basePath}/` : '';
    const portComplete: string = port ? `:${port}` : '';

    return `${protocol}://${host}${portComplete}/${basePathUrl}${endpoint}`;
  }

  /**
   * Get the api base path
   *
   * @returns the api base path
   */
  public getApiBasePath () {
    const restProperties: any = this.configService.config.app.rest;
    return restProperties.basePath;
  }

  /**
   * Get the endpoint url
   *
   * @param {string} endpointId The name of the endpoint
   * @param {*} [parameters={}] The parameters and query params
   * @returns {string} The endpoint url
   */
  public getEndpointUrl (endpointId: string, parameters = {}): string {
    const restProperties: any = this.configService.config.app.rest;
    if (!restProperties.endpoints[endpointId]) {
      throw new Error(('Endpoint is not defined, requesting default url'));
    }
    return this.generateEndpointUri(endpointId, parameters);
  }

  /**
   * Generate the endpoint uri
   *
   * @private
   * @param {string} endpointId The name of the endpoint
   * @param {*} [parameters={}] The parameters and query params
   * @returns {string} The endpoint uri
   */
  private generateEndpointUri (endpointId: string, parameters = {}): string {
    const restProperties: any = this.configService.config.app.rest;
    const { host, port, ssl, uri } = restProperties.endpoints[endpointId]
      ? restProperties.endpoints[endpointId]
      : restProperties;
    const basePath = restProperties.basePath;

    const protocol: string = ssl ? 'https' : 'http';
    const basePathUrl: string = basePath ? `${basePath}/` : '';
    const endpoint = this.replaceUriAndQueryStringParams(uri, parameters, endpointId);
    const portComplete: string = port ? `:${port}` : '';

    return `${protocol}://${host}${portComplete}/${basePathUrl}${endpoint}`;
  }

  /**
   * Replace the uri and query string params in url
   *
   * @private
   * @param {string} uri The uri
   * @param {*} parameters The params and query params
   * @param {string} endpointId The endpoint
   * @returns {string} The uri with params and query strings
   */
  private replaceUriAndQueryStringParams (uri: string, parameters: any, endpointId: string): string {
    const restProperties: any = this.configService.config.app.rest;
    const definedParams = restProperties.endpoints[endpointId].queryParams;
    let uriWithParamValues: string = uri ;
    this.concatCharacter = '?';

    for (const parameterKey in parameters) {
      if(parameters.hasOwnProperty(parameterKey)){
        const regexUrlParams = new RegExp(`:${parameterKey}([^\/&:]*)`, 'g');
        uriWithParamValues = uriWithParamValues.match(regexUrlParams)
          ? uriWithParamValues.replace(regexUrlParams, parameters[parameterKey])
          : uriWithParamValues;

        uriWithParamValues = this.setUrlParams(definedParams, uriWithParamValues, parameterKey, parameters);
      }
    }

    uriWithParamValues = this.urlWithParamsValues(uri, parameters, uriWithParamValues);

    return this.removeEndingSlash(uriWithParamValues);
  }

  /**
   * Set the url Params
   *
   * @private
   * @param {*} definedParams defined parameters
   * @param {string} uriWithParamValues uri with parameters
   * @param {string} parameterKey key of the parameters
   * @param {*} parameters parameters
   * @returns uri with parameters
   */
  private setUrlParams(definedParams: any, uriWithParamValues: string, parameterKey: string, parameters: any) {
    if (definedParams) {
      uriWithParamValues = definedParams.includes(parameterKey)
        ? `${uriWithParamValues}${this.concatCharacter}${parameterKey}=${parameters[parameterKey]}`
        : uriWithParamValues;
      this.concatCharacter = definedParams.includes(parameterKey) ? '&' : '?';
    }
    return uriWithParamValues;
  }

  /**
   * Set the uri with parameters
   *
   * @private
   * @param {string} uri uri
   * @param {*} parameters parameters
   * @param {string} uriWithParamValues uri with param values
   * @returns url with params values
   */
  private urlWithParamsValues(uri: string, parameters: any, uriWithParamValues: string) {
    const matchUrlParams = uri.match(/:([a-zA-Z0-9_-])+/g);

    if (matchUrlParams) {
      matchUrlParams.forEach((value: string, index: string | number) => {
        if (parameters[index] !== value.replace(':', '')) {
          uriWithParamValues = uriWithParamValues.replace(value, '');
        }
      });
    }
    return uriWithParamValues;
  }

  /**
   * Uri without the ending slash
   *
   * @private
   * @param {string} urlWithParamsValues uri with params
   * @returns uri with remove ending slash
   */
  private removeEndingSlash (urlWithParamsValues: string){
    return urlWithParamsValues.endsWith('/')
      ? urlWithParamsValues.substring(0, urlWithParamsValues.lastIndexOf('/'))
      : urlWithParamsValues;
  }
}
