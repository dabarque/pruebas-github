// angular imports
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { SessionStorageService } from './session-storage.service';
import { SecurityService } from '@ng-darwin/security';
import { MatDialog } from '@angular/material';
import { ModalComponent } from '../components/modal/modal.component';
import { ExpedientService } from './expedient.service';
import { Subject, Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class UtilsService {

    public idExpedient: any;
    public appObject: any;

    // Shared variables
    private readonly myMessage = new Subject<string>();

    constructor(
        private readonly router: Router,
        private readonly sessionStorageService: SessionStorageService,
        private readonly securityService: SecurityService,
        private readonly dialog: MatDialog,
        private readonly expedientService: ExpedientService
    ) {
    }

    // Getter for shared variables
    getMessage(): Observable<string> {
        return this.myMessage.asObservable();
    }

    // Setter for shared variables
    updateMessage(message: string) {
        this.myMessage.next(message);
    }

    cancelExpedient(idExpedient: any, isGoBack?: any, intervalIDs?: any) {
        if (!idExpedient) {
            this.logoutSession();
        } else {
            this.idExpedient = idExpedient;
            this.openModal('exitFromSign', true, isGoBack, intervalIDs)
        }
    }

    logoutSession() {
        // Delete sessionStorage
        this.sessionStorageService.deleteSessionStorage();
        // Kill the darwin session
        this.securityService.killSession();
        // Navigate to the logout page
        this.router.navigate(['/logout']);
    }

    /**
     * Open the modal window
     *
     * @param {string} bodyText Paremeter with the text of the modal body
     */
    openModal(bodyText: string, buttons: any, isGoBack: boolean, intervalIDs?: any) {
        const dialogRef = this.dialog.open(ModalComponent, {
            data: {
                title: 'warning',
                bodyText,
                buttons
            }
        });
        // Close the modal when click continue button
        dialogRef.afterClosed().subscribe((result: any) => {
            if (result) {
                // Stop intervals
                if (intervalIDs) {
                    if (intervalIDs.length > 0) {
                        intervalIDs.forEach((element: any) => {
                            window.clearInterval(element)
                        });
                    }
                }
                // Save cards values
                this.expedientService.cancelExpedient(this.idExpedient).subscribe(result => {
                    this.modalCancelStatus(result, isGoBack)
                });
            }
        });
    }

    modalCancelStatus(result: any, isGoBack: any) {
        if (result.cancelStatus === 'OK' && !isGoBack) {
            this.logoutSession();
        } else if (result.cancelStatus === 'KO') {
            const buttons = isGoBack ? false : true;
            this.openCancelKoModal(`${result.error.errorCode}`, buttons, isGoBack);
        } else if (result.cancelStatus === 'OK' && isGoBack) {
            this.appObject = this.sessionStorageService.getSessionStorage();
            this.appObject.localContracts.partenonPAN = {};
            this.appObject.idExpedient = '';
            this.appObject.documents = [];
            this.sessionStorageService.setSessionStorage(this.appObject);
            this.router.navigate(['/customization'], {
                queryParams: {
                    back: 'y'
                }
            });
        }
    }

    /**
     * Open the modal window
     *
     * @param {string} bodyText Paremeter with the text of the modal body
     */
    openCancelKoModal(bodyText: string, buttons: any, isGoBack?: boolean) {
        const dialogRef = this.dialog.open(ModalComponent, {
            data: {
                title: 'warning',
                bodyText,
                buttons
            }
        });
        // Close the modal when click continue button
        dialogRef.afterClosed().subscribe((result: any) => {
            if (result && !isGoBack) {
                this.logoutSession();
            }
        });
    }

}