// angular imports
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// application services import
import { RestService } from '../../shared/services/rest.service';

@Injectable({
  providedIn: 'root'
})
export class ExpedientService {

  constructor (private readonly http: HttpClient, private readonly rest: RestService) {
  }

  /**
   * Cancel the expedient
   *
   * @param {string} expedientId The expedient id
   * @returns {Observable<any>} The service observable
   */
  cancelExpedient (idExpedient: string): Observable<any> {
    const request$ = this.http.put(this.rest.getEndpointUrl(`cancelExp`, {idExpedient}), '');
    return request$;
  }
}