// angular imports
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// application services import
import { RestService } from '../../shared/services/rest.service';

@Injectable({
    providedIn: 'root'
})
export class HireService {

    constructor(private readonly http: HttpClient, private readonly rest: RestService) {
    }

    /**
     * Get the observable for the carousel service
     *
     * @param {string} angularObject The full object
     * @returns {Observable<any>} The service observable
     */
    hireExpedient (
        angularObject: object
    ): Observable<any> {
        const request$ = this.http.post<any>(this.rest.getEndpointUrl(`hire`), angularObject);
        return request$;
    }
}