// angular imports
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// applications services
import { RestService } from '../../shared/services/rest.service';

@Injectable({
  providedIn: 'root'
})
export class BeneficiariesService {

  constructor (private readonly http: HttpClient, private readonly rest: RestService) {
  }

  /**
   * Get the observable for the benefeciaries service
   *
   * @param {string} personId The user id
   * @param {string} personType The user type
   * @param {string} productId The product id
   * @param {string} subProductId The subproduct Id
   * @returns {Observable<any>} The service observable
   */
  fetchBeneficiariesAndAccountInfo (
    personId: string,
    personType: string,
    productId: string,
    subProductId: string
  ): Observable<any> {
    const request$ = this.http.get<any>(this.rest.getEndpointUrl(`beneficiaries`, {personType, personId, productId, subProductId}));
    return request$;
  }

  /**
   * Filter the accounts
   *
   * @param {any[]} accounts Array of accounts
   * @returns {*} Return the filter accounts
   */
  filterAccountsWithoutBalance(accounts: any[]): any{
    return accounts.filter(account =>  account.name !== '');
  }

  /**
   * Filter the representatives with OK state
   *
   * @param {any[]} representatives Array of representatives
   * @returns {any[]} Return the filter representatives
   */
  filterOkRepresentatives(representatives: any[]): any[] {
    return representatives.filter(representative =>  representative.state === 'OK' );
  }

  /**
   * Unchecked all the representatives
   *
   * @param {any[]} representatives Array of representatives
   * @returns {any[]} Array of unchecked representatives
   */
  initializeUncheckedRepresentatives(representatives: any[]): any[] {
    representatives.forEach(element => element.checked = false );
    return representatives;
  }
}