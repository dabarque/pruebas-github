// angular imports
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// application services import
import { SessionStorageService } from '../../shared/services/session-storage.service';
import { RestService } from '../../shared/services/rest.service';

@Injectable({
  providedIn: 'root'
})
export class DocumentsService {

  constructor(
    private readonly http: HttpClient,
    private readonly rest: RestService,
    private readonly sessionStorageService: SessionStorageService
  ) {
  }

  /**
   * Get the observable for the document service
   *
   * @returns {Observable<any>} The service observable
   */
  fetchDocuments(): Observable<any> {
    const request$ = this.http.post<any>(this.rest.getEndpointUrl(`documents`), this.requestJson());
    return request$;
  }

  /**
   * Get pdf document on Base64
   *
   * @returns {Observable<any>} The service observable
   */
  getPdfDocument(gnId: string, documentType: string): Observable<any> {
    const request$ = this.http.get<any>(this.rest.getEndpointUrl(`getDocument`, { gnId, documentType }));
    return request$;
  }

  /**
   * Get the Json for the documents service request
   */
  requestJson(): {} {
    // Get the sessionStorage object
    const jsonObject: any = this.sessionStorageService.getSessionStorage();
    return jsonObject;
  }

  /**
   * Obtain if hasCufed
   */
  validarCufed(
    angularObject: object
  ): Observable<any> {
    const request$ = this.http.post<any>(this.rest.getEndpointUrl(`validarCufed`), angularObject);
    return request$;
  }
}