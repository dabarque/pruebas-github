import { async, TestBed } from '@angular/core/testing';

import { RestService } from './rest.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ConfigTestingModule } from '@ng-darwin/config';
import { LoggerTestingModule } from '@ng-darwin/logger';
import { SecurityTestingModule } from '@ng-darwin/security';

describe('RestService', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [  ],
      imports: [
        HttpClientTestingModule,
        ConfigTestingModule.forRoot({
          appKey: 'appKey_mock',
          appName: 'appName_mock',
          app: {
            docRoutes: {
              dw: 'dw_url_mock',
              jsonServer: 'jsonServer_url_mock',
              ng: 'ng_url_mock',
              ngCli: 'ngCli_url_mock'
            },
            itemsPerPage: '5',
            rest: {
              host: 'localhost',
              port: 3000,
              ssl: false,
              basePath: 'api/v1',
              endpoints: {
                carousel: {
                  host: 'localhost',
                  port: 3000,
                  ssl: false,
                  method: 'GET',
                  uri: 'persons/:personType/:personId/carousel'
                },
                beneficiaries: {
                  host: 'localhost',
                  port: 3000,
                  ssl: false,
                  method: 'GET',
                  uri: 'persons/:personType/:personId/beneficiaries',
                  queryParams: [
                    'productId',
                    'subProductId'
                  ]
                },
                customization: {
                  host: 'localhost',
                  port: 3000,
                  ssl: false,
                  method: 'POST',
                  uri: 'persons/customization'
                }
              }
            }
          }
        }),
        SecurityTestingModule,
        LoggerTestingModule
      ],
      providers: [ RestService ]
    })
    .compileComponents();
  }));

  it('should be created', () => {
    const service: RestService = TestBed.get(RestService);
    expect(service).toBeTruthy();
  });
});
