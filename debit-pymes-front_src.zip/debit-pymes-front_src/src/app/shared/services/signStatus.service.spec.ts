import { async, TestBed } from '@angular/core/testing';

import { SignService } from './sign.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ConfigTestingModule } from '@ng-darwin/config';
import { LoggerTestingModule } from '@ng-darwin/logger';
import { SecurityTestingModule } from '@ng-darwin/security';

describe('SignService', () => {
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [],
            imports: [
                HttpClientTestingModule,
                ConfigTestingModule.forRoot({
                    appKey: 'appKey_mock',
                    appName: 'appName_mock',
                    app: {
                        docRoutes: {
                            dw: 'dw_url_mock',
                            jsonServer: 'jsonServer_url_mock',
                            ng: 'ng_url_mock',
                            ngCli: 'ngCli_url_mock'
                        },
                        itemsPerPage: '5',
                        rest: {
                            host: 'localhost',
                            port: 3000,
                            ssl: false,
                            basePath: 'api/v1',
                            endpoints: {
                                carousel: {
                                    host: 'localhost',
                                    port: 3000,
                                    ssl: false,
                                    method: 'GET',
                                    uri: 'persons/:personType/:personId/carousel'
                                },
                                beneficiaries: {
                                    host: 'localhost',
                                    port: 3000,
                                    ssl: false,
                                    method: 'GET',
                                    uri: 'persons/:personType/:personId/beneficiaries',
                                    queryParams: [
                                        'productId',
                                        'subProductId'
                                    ]
                                },
                                customization: {
                                    host: 'localhost',
                                    port: 3000,
                                    ssl: false,
                                    method: 'POST',
                                    uri: 'persons/customization'
                                },
                                sign: {
                                    host: "localhost",
                                    port: 3000,
                                    ssl: false,
                                    method: "GET",
                                    uri: "persons/sign/:bodyRequest"
                                },
                                documents: {
                                    host: "localhost",
                                    port: 3000,
                                    ssl: false,
                                    method: "GET",
                                    uri: "persons/documents"
                                },
                                signStatus: {
                                    host: "localhost",
                                    port: 3000,
                                    ssl: false,
                                    method: "GET",
                                    uri: "persons/signStatus/:signatureId"
                                }
                            }
                        }
                    }
                }),
                SecurityTestingModule,
                LoggerTestingModule
            ],
            providers: [SignService]
        })
            .compileComponents();
    }));

    it('should be created', () => {
        const service: SignService = TestBed.get(SignService);
        expect(service).toBeTruthy();
    });
});