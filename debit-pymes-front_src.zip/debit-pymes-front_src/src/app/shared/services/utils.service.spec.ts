import { async, TestBed, ComponentFixture } from '@angular/core/testing';

import { Router } from '@angular/router';
import { UtilsService } from './utils.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ConfigTestingModule } from '@ng-darwin/config';
import { LoggerTestingModule } from '@ng-darwin/logger';
import { SecurityTestingModule } from '@ng-darwin/security';
import { ModalComponent } from '../../../app/shared/components/modal/modal.component';
import { AngularMaterialModule } from '../../../app/shared/angular-material.module';
import { TranslateModule } from '@ngx-translate/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

@NgModule({
  imports: [],
  declarations: [],
  entryComponents: [ModalComponent]
})
export class FakeTestDialogModule { }

describe('UtilsService', () => {
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ ModalComponent ],
            imports: [
                BrowserAnimationsModule,
                HttpClientTestingModule,
                AngularMaterialModule,
                TranslateModule.forRoot(),
                ConfigTestingModule.forRoot({
                    appKey: 'appKey_mock',
                    appName: 'appName_mock',
                    app: {
                        docRoutes: {
                            dw: 'dw_url_mock',
                            jsonServer: 'jsonServer_url_mock',
                            ng: 'ng_url_mock',
                            ngCli: 'ngCli_url_mock'
                        },
                        itemsPerPage: '5',
                        rest: {
                            host: 'localhost',
                            port: 3000,
                            ssl: false,
                            basePath: 'api/v1',
                            endpoints: {
                                carousel: {
                                    host: 'localhost',
                                    port: 3000,
                                    ssl: false,
                                    method: 'GET',
                                    uri: 'persons/:personType/:personId/carousel'
                                },
                                beneficiaries: {
                                    host: 'localhost',
                                    port: 3000,
                                    ssl: false,
                                    method: 'GET',
                                    uri: 'persons/:personType/:personId/beneficiaries',
                                    queryParams: [
                                        'productId',
                                        'subProductId'
                                    ]
                                },
                                customization: {
                                    host: 'localhost',
                                    port: 3000,
                                    ssl: false,
                                    method: 'POST',
                                    uri: 'persons/customization'
                                },
                                cancelExp: {
                                    host: "localhost",
                                    port: 3000,
                                    ssl: false,
                                    method: "GET",
                                    uri: "cancelExpedient/:idExpedient"
                                }
                            }
                        }
                    }
                }),
                SecurityTestingModule,
                LoggerTestingModule,
                FakeTestDialogModule
            ],
            providers: [
              UtilsService,
              {
                provide: Router, useClass: class {
                  navigate = jasmine.createSpy("navigate");
                  navigateByUrl(url: string) {
                    return url;
                  }
                }
              }
            ]
        })
            .compileComponents();
    }));

    it('should be created', () => {
        const service: UtilsService = TestBed.get(UtilsService);
        expect(service).toBeTruthy();
    });

    it('should logoutSession', () => {
        const service: UtilsService = TestBed.get(UtilsService);
        expect(service.logoutSession()).toBeUndefined();
    });

    it('should cancelExpedient true', () => {
        const idExpedient = 'eueue';
        const service: UtilsService = TestBed.get(UtilsService);
        expect(service.cancelExpedient(idExpedient)).toBeUndefined();
    });

    it('should cancelExpedient false', () => {
        const idExpedient = '';
        const service: UtilsService = TestBed.get(UtilsService);
        expect(service.cancelExpedient(idExpedient)).toBeUndefined();
    });

    it('should cancelExpedient true with goBack', () => {
        const idExpedient = 'eueue';
        const service: UtilsService = TestBed.get(UtilsService);
        expect(service.cancelExpedient(idExpedient, true)).toBeUndefined();
    });

    it('should cancelExpedient false with goBack', () => {
        const idExpedient = '';
        const service: UtilsService = TestBed.get(UtilsService);
        expect(service.cancelExpedient(idExpedient, true)).toBeUndefined();
    });

    it('should updateMessage', () => {
        const message = 'prueba';
        const service: UtilsService = TestBed.get(UtilsService);
        expect(service.updateMessage(message)).toBeUndefined();
    });

    it('should openCancelKoModal', () => {
        const service: UtilsService = TestBed.get(UtilsService);
        expect(service.openCancelKoModal('prueba', true)).toBeUndefined();
    });

    it('should modalCancelStatus OK false', () => {
        const result = {
            cancelStatus: 'OK'
        }
        const service: UtilsService = TestBed.get(UtilsService);
        expect(service.modalCancelStatus(result, false)).toBeUndefined();
    });

    it('should modalCancelStatus KO', () => {
        const result = {
            cancelStatus: 'KO'
        }
        const service: UtilsService = TestBed.get(UtilsService);
        expect(service.modalCancelStatus(result, true)).toBeUndefined();
    });

    it('should modalCancelStatus OK true', () => {
        const result = {
            cancelStatus: 'OK'
        }
        const service: UtilsService = TestBed.get(UtilsService);
        expect(service.modalCancelStatus(result, true)).toBeUndefined();
    });
});