import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CardsComponent } from './components/cards/cards.component';
import { BeneficiariesComponent } from './components/beneficiaries/beneficiaries.component';
import { CustomizationComponent } from './components/customization/customization.component';
import { LogoutComponent } from './shared/components/logout/logout.component';
import { SignComponent } from './components/sign/sign.component';

const routes: Routes = [
  {
    path: '',
    component: CardsComponent
  },
  {
    path: 'cards',
    component: CardsComponent
  },
  {
    path: 'beneficiaries',
    component: BeneficiariesComponent
  },
  {
    path: 'customization',
    component: CustomizationComponent
  },
  {
    path: 'logout',
    component: LogoutComponent
  },
  {
    path: 'sign',
    component: SignComponent
  },
  {
    path: '**',
    component: CardsComponent
  }
];

/**
 * AppRoutingModule
 * Designed to be the root routing module.
 *
 * imports:
 *  - RouterModule. Adds router directives and providers.
 *
 * exports:
 *  - RouterModule. The module with the configured routes.
 */
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
