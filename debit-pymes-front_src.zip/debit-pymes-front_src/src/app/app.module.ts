// Angular components
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { environment } from '../environments/environment';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

// Darwin components
import { ConfigModule } from '@ng-darwin/config';
import { SecurityModule } from '@ng-darwin/security';
import { LoggerModule } from '@ng-darwin/logger';

// App Components
import { HeaderComponent } from './shared/components/header/header.component';
import { CardsComponent } from './components/cards/cards.component';
import { CardComponent } from './components/cards/components/card/card.component';
import { ErrorComponent } from './shared/components/error/error.component';
import { SuccessComponent } from './shared/components/success/success.component';
import { BeneficiariesComponent } from './components/beneficiaries/beneficiaries.component';
import { ModalComponent } from './shared/components/modal/modal.component';
import { LogoutComponent } from './shared/components/logout/logout.component';
import { BeneficiariesTableComponent } from './components/beneficiaries/components/table/beneficiaries-table.component';
import { CustomizationComponent } from './components/customization/customization.component';
import { CustomizationTableComponent } from './components/customization/components/table/customization-table.component';

// Services
import { CarouselService } from './shared/services/carousel.service';
import { BeneficiariesService } from './shared/services/beneficiaries.service';
import { CustomizationService } from './shared/services/customization.service';
import { SessionStorageService } from './shared/services/session-storage.service';

// Angular material module
import { AngularMaterialModule } from './shared/angular-material.module';
import { SignComponent } from './components/sign/sign.component';

/**
 * AppModule
 * Designed to be the root module.
 *
 * imports:
 *  - BrowserModule. Required infrastructure for all Angular apps.
 *  - HttpClientModule. Configures the DI for HttpClient.
 *  - ConfigModule. Configures the DI for ConfigService..
 *  - SecurityModule. Configures the DI for SecurityService
 *  - LoggerModule. Configures the DI for LoggerService.
 *  - AppRoutingModule. Module with the configured routes
 *
 * declarations:
 *  - AppComponent. Root component in charge of being the app shell
 *
 * bootstrap:
 *   - AppComponent
 */
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    ErrorComponent,
    SuccessComponent,
    BeneficiariesComponent,
    BeneficiariesTableComponent,
    ModalComponent,
    LogoutComponent,
    CustomizationComponent,
    CustomizationTableComponent,
    SignComponent,
    CardsComponent,
    CardComponent,
  ],
  entryComponents: [ModalComponent],
  imports: [
    BrowserModule,
    HttpClientModule,
    ConfigModule.forRoot({
      logEvent: {
        level: environment.configLogLevel,
        handler(ev) { console.log('Log event from Config module:', ev); }
      },
      errorEvent: {
        handler(ev) { console.error('Error event from Config module:', ev); }
      },
      configLoadedEvent: {
        handler(ev) { console.log('ConfigLoaded event from Config module:', ev); }
      }
    }),
    SecurityModule,
    LoggerModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    AngularMaterialModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    })
  ],
  providers: [
    BeneficiariesService,
    CustomizationService,
    SessionStorageService,
    CarouselService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}
