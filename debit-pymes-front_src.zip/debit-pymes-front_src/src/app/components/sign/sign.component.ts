// Angular imports
import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { Router } from '@angular/router';

// Shared components imports
import { LOGO_URL } from '../../shared/constants/utils.constants';
import { ModalComponent } from '../../shared/components/modal/modal.component';
import { SessionStorageService } from '../../shared/services/session-storage.service';
import { DocumentsService } from '../../shared/services/documents.service';
import { SignService } from '../../shared/services/sign.service';
import { SignStatusService } from '../../shared/services/signStatus.service';

// angular material imports
import { MatDialog } from '@angular/material';
import { LoggerService } from '@ng-darwin/logger';

import { ConfigService } from '@ng-darwin/config';
import { UtilsService } from '../../shared/services/utils.service';
import { HireService } from '../../shared/services/hire.service';
import { TranslateService } from '@ngx-translate/core';
import { finalize, switchMap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

@Component({
  selector: 'app-sign',
  templateUrl: './sign.component.html',
  styleUrls: ['./sign.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class SignComponent implements OnInit {
  // Sign variables
  public toggle = false;
  public signUrl: any;
  public documents: any = [];
  public signRequest: any;
  public iframeHidden = true;
  public notMandatoryFields = true;

  // Variables of document y signer
  public documentIndex: any;
  public signerIndex: any;

  // Variables to signRequest
  public idExpedient!: any;
  public signerName: any;
  public language: any;
  public sessionSignerIndex: any;
  public sessionDocumentIndex: any;

  // Path images variables
  public logoUrl = LOGO_URL;

  // Manage success page
  public isSuccess = false;
  public successMessage!: string;

  // Manage error variables
  public isError = false;
  public errorExpedient = false;
  public errorMessage!: string;
  public errorMessageSecondLine!: string;
  public buttonKeys: any[] = [];
  public tooltipWatch: any;

  // sessionStorage variables
  public appObject!: any;
  public cardDescription!: string;
  public branchUser!: string;
  public branchCode!: string;
  public personId!: string;
  public personType!: string;
  public productId!: string;
  public subProductId!: string;
  public representatives!: any[];
  public partenonPAN!: any;

  // app variables
  public filteredDocuments!: any[];
  public documentsMandatoryByRepresentative: any = [];
  public documentsNoMandatoryByRepresentative: any[] = [];
  public allDocumentsSigned = false;
  public selectedCode!: string;
  public selectedAccount!: string;

  // charging variables
  public isCharging: any;
  public chargingMessage = 'cufedMessage';
  public isOrdefeTimeOut = false;

  // config variables
  public intervalRepetitions: any;
  public intervalSeconds: any;
  public executeOrdefe: any;

  // ordefe window
  public ordefeWindow: any;
  public intervalId: any = [];

  public messageFromSibling = 'Prueba';
  public subscription: any;

  constructor(
    private readonly router: Router,
    private readonly sessionStorageService: SessionStorageService,
    private readonly documentsService: DocumentsService,
    private readonly signService: SignService,
    private readonly signStatusService: SignStatusService,
    private readonly dialog: MatDialog,
    private readonly loggerService: LoggerService,
    private readonly configService: ConfigService,
    private readonly utilsService: UtilsService,
    private readonly hireService: HireService,
    private readonly translate: TranslateService
  ) {
    this.translate.get('tooltipWatch').subscribe(data => { this.tooltipWatch = data })
    // Subscription variables
    this.subscription = this.utilsService.getMessage()
      .subscribe(mymessage => this.messageFromSibling = mymessage)
  }

  ngOnInit() {
    if (!sessionStorage.getItem('appObject')) {
      this.router.navigate(['/cards']);
    } else {

      // Scroll to the top of the page
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });

      // Charging message
      this.isCharging = true;
      // Get the info from sessionStorage
      this.getInfoSessionStorage();

      // Obtain the Cufed state
      this.documentsService.validarCufed(this.appObject).subscribe(result => {
        // If error the user is informed
        if (result.error.errorCode) {
          this.isError = true;
          this.errorMessage = result.error.errorCode;
          this.isCharging = false;
        } else if ( !this.isSuccess ) {
          // If OK we have been CUFED status S/N
          // Process response and update information only if the hiring proccess is on going
          result.representatives.forEach((representative: any) => {
            // Each person is associated with their CUFED status 
             this.appObject.representatives.find(
               (element: any) => element.personId === representative.personId).hasCufed = representative.cufed;
           });
          // Save status CUFED in the object by their representative
          this.sessionStorageService.setSessionStorage(this.appObject);
          // Change message for next step
          this.chargingMessage = 'chargingMessage';

          // Get the documents
          this.documentsService.fetchDocuments().subscribe({
            next: (elem: any) => {
              // If Error
              if (elem.error.errorCode) {
                // If the service get an errorCode, the ErrorComponent is shown with the message
                this.isError = true;
                this.errorMessage = elem.error.errorCode;
                this.errorMessageSecondLine = elem.error.errorDesc;
              } else {
                // If OK
                // Process response and update information
                this.successFetchDocuments(elem);
              }
              this.isCharging = false;
            },
            error: (error: any) => {
              // If the services get an http error, the ErrorComponent is shown with the error description
              this.isError = true;
              this.errorMessage = 'documentServiceError';
              // The error is logged in Kibana
              this.loggerService.logError({
                log: error,
                component: 'SignComponent'
              });
              this.isCharging = false;
            }
          })
        };
      },
        error => {
          // If the services get an http error, the ErrorComponent is shown with the error description
          this.isError = true;
          this.errorMessage = 'ERROR_CUFED01';
          // The error is logged in Kibana
          this.loggerService.logError({
            log: error,
            component: 'SignComponent'
          });
          this.isCharging = false;
        }
      );
      this.selectedAccount = this.selectedCode;
    }
  }

  successFetchDocuments(elem: any) {
    // Get the partenonPAN and the expedient id
    this.partenonPAN = elem.partenonPAN;
    this.idExpedient = elem.idExpedient;

    // Get the documents, partenonPAN & idExpedient and add it to the appObject
    this.appObject.documents = elem.documents;
    this.appObject.idExpedient = this.idExpedient;
    this.appObject.localContracts.partenonPAN = this.partenonPAN;
    this.sessionStorageService.setSessionStorage(this.appObject);

    // Get all the documents by the representative and save the data in object
    elem.documents.forEach((element: any) => {
      // Match the representatives in the sessionStorage object with the signers from the service
      this.representatives.forEach(representantive => {
        this.filteredDocuments =
          element.signers.filter((signer: any) => signer.personId === representantive.personId);
        if (this.filteredDocuments.length > 0) {
          // Save all the documents in the object by their representative
          this.setMandatoryByRepresentative(element, representantive);
        }
      });
    });
  }

  /**
   * Set the object with all the documents by representative
   */
  setMandatoryByRepresentative(element: any, representantive: any) {
    // If the document is mandatory, the data is saved in another object
    const DEFAULT_BUTTONS = {
      signButton: true,
      errorIcon: false,
      successIcon: false,
      watchIcon: false,
      tooltipError: '',
    }

    if (element.mandatory === 'S') {
      // If the representative is in the object, push the document into this representative
      const representativeFound = this.documentsMandatoryByRepresentative.find((id: any) => id.personId === representantive.personId)

      if (representativeFound) {
        representativeFound.documents.push({
          documentType: element.documentType,
          gnId: element.gnId,
          buttons: DEFAULT_BUTTONS
        });
        // If the representative is not in  the object, create the representative
      } else {
        this.documentsMandatoryByRepresentative.push({
          name: representantive.name,
          personId: representantive.personId,
          personType: representantive.personType,
          document: representantive.document,
          documents: [{
            documentType: element.documentType,
            gnId: element.gnId,
            buttons: DEFAULT_BUTTONS
          }]
        });
      }

      // If the document is not mandatory, the data is saved in another object
    } else {
      // If the representative is in the object, push the document into this representative
      if (this.documentsNoMandatoryByRepresentative.find((id: any) => id.personId === representantive.personId)) {
        this.documentsNoMandatoryByRepresentative.find((id: any) => id.personId === representantive.personId).documents.push({
          documentType: element.documentType,
          gnId: element.gnId,
          buttons: DEFAULT_BUTTONS
        });
        // If the representative is not in the object, create the representative
      } else {
        this.documentsNoMandatoryByRepresentative.push({
          name: representantive.name,
          personId: representantive.personId,
          personType: representantive.personType,
          document: representantive.document,
          documents: [{
            documentType: element.documentType,
            gnId: element.gnId,
            buttons: DEFAULT_BUTTONS
          }]
        });
      }
    }
  }

  /**
   * Get all the necessary sessionStorage Data
   */
  getInfoSessionStorage() {
    // Get the sessionStorage object
    this.appObject = this.sessionStorageService.getSessionStorage();
    if (this.appObject.localContracts && this.appObject.localContracts.localContract && this.appObject.office && this.appObject.company) {
      // Get the info from office and card
      this.cardDescription = this.appObject.localContracts.productDesc;
      // Get the branch user
      this.branchUser = this.appObject.office.officeTeller;
      // Get the branch 
      this.branchCode = this.appObject.office.officeId;
      // Get the company
      this.personId = this.appObject.company.personId;
      this.personType = this.appObject.company.personType;
      // Get the product 
      this.productId = this.appObject.localContracts.productId;
      this.subProductId = this.appObject.localContracts.subProductId;
      // Get the info from representatives
      this.selectedCode = this.appObject.localContracts.localContract.contractId;
    }
    this.representatives = this.appObject.representatives;
    // Get the expedient sign
    this.idExpedient = this.appObject.idExpedient;
    // Get the language document
    this.language = this.appObject.language;

  }

  /**
   * Go to the previous page
   */
  goBack() {
    // If there is a Exp, it must be canceled
    if (this.idExpedient) {
      this.utilsService.cancelExpedient(this.idExpedient, true, this.intervalId);
    } else {
      //Delete for the session this information
      this.appObject.localContracts.partenonPAN = {};
      this.appObject.idExpedient = '';
      this.appObject.documents = [];
      this.sessionStorageService.setSessionStorage(this.appObject);
      this.router.navigate(['/customization'], {
        queryParams: {
          back: 'y'
        }
      });
    }
  }

  // Show message with sign result
  displayMessage(evt: any) {
    // If OK change de icon for information the user
    if (evt.data === 'OK') {
      this.documentsMandatoryByRepresentative[this.signerIndex].documents[this.documentIndex].buttons.errorIcon = false;
      this.documentsMandatoryByRepresentative[this.signerIndex].documents[this.documentIndex].buttons.watchIcon = true;
      this.appObject.documents[this.sessionDocumentIndex].signers[this.sessionSignerIndex].requestSignature = 'S';
      this.sessionStorageService.setSessionStorage(this.appObject);
      this.intervalRepetitions = this.configService.config.app.intervalRepetitions;
      this.intervalSeconds = this.configService.config.app.intervalSeconds;
      this.setIntervalTimes(this.intervalSeconds, this.intervalRepetitions, this.sessionDocumentIndex, this.sessionSignerIndex, this.signerIndex, this.documentIndex);
    } else if (evt.data === 'KO') {
      // If KO change de icon for new execute the action
      this.appObject.documents[this.sessionDocumentIndex].signers[this.sessionSignerIndex].signatureStatus = 'KO';
      this.sessionStorageService.setSessionStorage(this.appObject);
      this.documentsMandatoryByRepresentative[this.signerIndex].documents[this.documentIndex].buttons.errorIcon = true;
      this.documentsMandatoryByRepresentative[this.signerIndex].documents[this.documentIndex].buttons.signButton = true;
    }
  }

  // Interval calling verifiRequest service
  setIntervalTimes(delay: any, repetitions: any, sessionDocumentIndex: any, sessionSignerIndex: any, signerIndex: any, documentIndex: any) {
    let x = 0;
    const intervalID = window.setInterval(() => {
      x++;
      this.signStatusService.fetchSignStatus(
        this.appObject.documents[sessionDocumentIndex].signers[sessionSignerIndex].signatureId).subscribe(elem => {
          if( this.isSuccess ) {
            window.clearInterval(intervalID);
            return;
          }          
          // The assignment of descError is done here to reduce 'if' nesting
          const descError = elem.error ? elem.error.errorDesc : 'Error';
          if (elem.documents.signatureStatus === 'OK') {
            // If OK change de icon for information the user
            this.appObject.documents[sessionDocumentIndex].signers[sessionSignerIndex].signatureStatus = 'OK';
            this.sessionStorageService.setSessionStorage(this.appObject);
            this.documentsMandatoryByRepresentative[signerIndex].documents[documentIndex].buttons.watchIcon = false;
            this.documentsMandatoryByRepresentative[signerIndex].documents[documentIndex].buttons.successIcon = true;
            window.clearInterval(intervalID);
          } else if (elem.documents.signatureStatus === 'KO' || x >= repetitions) {
            // If KO change de icon for new execute the action
            this.appObject.documents[sessionDocumentIndex].signers[sessionSignerIndex].signatureStatus = 'KO';
            this.sessionStorageService.setSessionStorage(this.appObject);
            this.documentsMandatoryByRepresentative[signerIndex].documents[documentIndex].buttons.watchIcon = false;
            this.documentsMandatoryByRepresentative[signerIndex].documents[documentIndex].buttons.errorIcon = true;
            this.documentsMandatoryByRepresentative[signerIndex].documents[documentIndex].buttons.signButton = true;
            this.documentsMandatoryByRepresentative[signerIndex].documents[documentIndex].buttons.tooltipError = descError;
            window.clearInterval(intervalID);
          }
        });
    }, delay)
    this.intervalId.push(intervalID);
    ;
  }

  // Get of sign URL and its call
  handleSignClick(
    signerType: string,
    signerId: string,
    documentId: string,
    documentGnId: string,
    documentIndex: any,
    signerIndex: any,
    documentsLength: any) {
    this.signerName = (this.representatives.find(elem => elem.personId === signerId)).name;
    this.documentIndex = documentIndex;
    this.signerIndex = signerIndex;
    const typeS = documentsLength === 1 ? 'N' : 'S';

    this.sessionDocumentIndex = this.appObject.documents.findIndex((elem: any) => elem.gnId === documentGnId);
    this.sessionSignerIndex =
      this.appObject.documents[this.sessionDocumentIndex].signers.findIndex((elem: any) => elem.personId === signerId);

    this.signService.fetchSignUrl(
      this.idExpedient, signerType + signerId, this.signerName, documentId, this.language, typeS
    ).subscribe(result => {
      this.signRequest = result;

      if (!this.signRequest.error || this.signRequest.error.errorCode === '') {
        // If OK we save the ID in session to be able to check its status
        this.documentsMandatoryByRepresentative[this.signerIndex].documents[this.documentIndex].buttons.signButton = false;
        this.appObject.documents[this.sessionDocumentIndex].signers[this.sessionSignerIndex].signatureId = this.signRequest.signatureId;
        this.sessionStorageService.setSessionStorage(this.appObject);

        // ordefe call
        localStorage.setItem('ordefeurl', this.signRequest.url);
        this.executeOrdefe = this.configService.config.app.executeOrdefe;
        const top = window.screen.height;
        const left = window.screen.width;
        this.ordefeWindow = window.open(this.signRequest.url, "_blank", 'width=50%,height=50%,top=' + top + ',left=' + left + '');
        // Interval para simular respuesta ordefe
        const ordefeSeconds: any = this.configService.config.app.ordefeTimeOut;
        const eventSimulated = { data: 'OK' };
        this.isOrdefeTimeOut = true;
        setTimeout(() => {
          this.isOrdefeTimeOut = false;
          this.displayMessage(eventSimulated);
          this.openModalOrdefe('closeOrdefe', true);
        }, ordefeSeconds)

        // Listener cuando obtengamos respuesta de ORDEFE
        // if (this.ordefeWindow.addEventListener) {
        //   this.ordefeWindow.addEventListener('message', this.displayMessage.bind(this), false);
        // } else {
        //   (this.ordefeWindow as any).attachEvent('onmessage', this.displayMessage.bind(this));
        // }

      } else if (this.signRequest.error && this.signRequest.error.errorCode !== '') {
        this.appObject.documents[this.sessionDocumentIndex].signers[this.sessionSignerIndex].signatureStatus = 'KO';
        this.sessionStorageService.setSessionStorage(this.appObject);
        this.documentsMandatoryByRepresentative[this.signerIndex].documents[this.documentIndex].buttons.errorIcon = true;
        this.documentsMandatoryByRepresentative[this.signerIndex].documents[this.documentIndex].buttons.signButton = true;
        this.documentsMandatoryByRepresentative[this.signerIndex].documents[this.documentIndex].buttons.tooltipError =
          this.signRequest.error.errorDesc;
      }
    },
      error => {
      //If hay error volvemos a permitir la solicitud de firma
        this.documentsMandatoryByRepresentative[this.signerIndex].documents[this.documentIndex].buttons.errorIcon = true;
        this.documentsMandatoryByRepresentative[this.signerIndex].documents[this.documentIndex].buttons.signButton = true;
        this.documentsMandatoryByRepresentative[this.signerIndex].documents[this.documentIndex].buttons.tooltipError = error;
      }
    );
  }

  /**
   * Open the Ordefe modal window
   *
   * @param {string} bodyText Paremeter with the text of the modal body
   */
  openModalOrdefe(bodyText: string, button: any) {
    const dialogRef = this.dialog.open(ModalComponent, {
      data: {
        title: 'warning',
        bodyText,
        button
      }
    });
    dialogRef.afterClosed().subscribe((result: any) => {
      if (result) {
        this.ordefeWindow.close();
      }
    });
  }

  /**
   * Exit the application, kill the session and delete the sessionStorage object
   */
  exit() {
    this.utilsService.cancelExpedient(this.idExpedient, false, this.intervalId);
  }

  /**
   *  Validate if all the documents has been signed
   */
  validateSignDocuments() {
    // Informamos al usuario de que se inicia la contratacion
    // se incorpora detalle de la situación en que queda el contrato segun las firmas
    this.openModal('hirethedocument', true);   
  }

  /**
   * Open the modal window
   *
   * @param {string} bodyText Paremeter with the text of the modal body
   */
  openModal(bodyText: string, buttons: any, errorDesc?: string) {
    let hiringDialogRef: any;
    const dialogRef = this.dialog.open(ModalComponent, {
      data: {
        title: 'warning',
        bodyText,
        buttons,
        errorDesc
      }
    });
    // Before closing confirmation modal, information message is displayed
    dialogRef.beforeClosed().pipe(
      switchMap((hireModalResult: Observable<any>) => {
        if (hireModalResult) {
          // But only with the OK
          hiringDialogRef = this.dialog.open(ModalComponent, {
            data: {
              title: 'warning',
              bodyText: 'Enviando la información a Medios de Pago para terminar el proceso de contratación; por favor espere.',
              buttons: false,
              errorDesc
            }
          });
          // Launch Hire
          const appObject = this.sessionStorageService.getSessionStorage();
          return this.hireService.hireExpedient(appObject);
        } else {
          // With Cancel exit without executing anything
          return of({ result: 'Cancel' });
        }
      }),
      // With the answer closed the message
      finalize(() => {
        if (hiringDialogRef) {
          hiringDialogRef.close();
        }
      })
    ).subscribe((hireResult: any) => {
      if (hireResult.result === 'OK') {
        // With OK delete session y the end
        this.isSuccess = true;
        this.successMessage = hireResult.status.statusDesc;
        this.sessionStorageService.deleteSessionStorage();
      } else if (hireResult.error && hireResult.error.errorCode) {
        // With error open modal with description error
        this.openModal(`${hireResult.error.errorCode}`, false, hireResult.error.errorDesc);
      }
    });
  }

  /**
   *  Handle the hire button event
   *
   */
  handleHire() {
    this.validateSignDocuments();
  }

  /**
   * Handle the click from the print document
   */
  handlePrintClick(gnId: string, documentType: string) {
    // Call to the get PDF document
    this.documentsService.getPdfDocument(gnId, documentType).subscribe(result => {

      // const pdfWindow: Window = window.open('') || new Window();

      // prueba base64 transform
      const data = result.document;
      const fileName = gnId + '.pdf';
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        const byteCharacters = atob(data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'application/pdf' });
        window.navigator.msSaveOrOpenBlob(blob, fileName);
      } else {
        const pdfWindow: Window = window.open(
          '', '_blank',
          'toolbar=yes,scrollbars=no,resizable=yes,top=500,left=500,width=400,height=400') || new Window();
        pdfWindow.document.write(
          '<iframe width="100%" height="100%" download src="data:application/pdf;base64, ' +
          encodeURI(result.document) + '"></iframe>'
        );
      }

      // If exist the field document, print it in the new tab
      // if (result.document) {
      //   // Print the document in Base 64
      //   pdfWindow.document.write(
      //     '<iframe width="100%" height="100%" src="data:application/pdf;base64, ' +
      //     encodeURI(result.document) + '"></iframe>'
      //   );
      //   // Set the tab title
      //   pdfWindow.document.title = `${gnId} - ${documentType}`;
      // } else {
      //   // Print the document in Base 64
      //   pdfWindow.document.write(
      //     '<iframe width="100%" height="100%" src="data:application/pdf;base64, ' +
      //     encodeURI(result) + '"></iframe>'
      //   );
      //   // Set the tab title
      //   pdfWindow.document.title = `${gnId} - ${documentType}`;
      // }
    });
  }
}
