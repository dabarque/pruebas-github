import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';

import { Router } from '@angular/router';

import { SignComponent } from './sign.component';
import { HeaderComponent } from 'src/app/shared/components/header/header.component';
import { ErrorComponent } from 'src/app/shared/components/error/error.component';
import { SuccessComponent } from 'src/app/shared/components/success/success.component';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';
import { TranslateModule } from '@ngx-translate/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ConfigTestingModule } from '@ng-darwin/config';
import { LoggerTestingModule } from '@ng-darwin/logger';
import { SecurityTestingModule } from '@ng-darwin/security';
import { AngularMaterialModule } from 'src/app/shared/angular-material.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SignService } from 'src/app/shared/services/sign.service';
import { SignStatusService } from 'src/app/shared/services/signStatus.service';
import { DocumentsService } from 'src/app/shared/services/documents.service';
import { NgModule } from '@angular/core';
import { of } from 'rxjs';

@NgModule({
  imports: [],
  declarations: [],
  entryComponents: [ModalComponent]
})
export class FakeTestDialogModule { }

describe('SignComponent', () => {
  let signService: any;
  let signStatusService: any;
  let documentsService: any;
  let component: SignComponent;
  let fixture: ComponentFixture<SignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        SignComponent,
        HeaderComponent,
        ErrorComponent,
        SuccessComponent,
        ModalComponent
      ],
      imports: [
        BrowserAnimationsModule,
        TranslateModule.forRoot(),
        HttpClientTestingModule,
        ConfigTestingModule.forRoot({
          appKey: 'appKey_mock',
          appName: 'appName_mock',
          app: {
            docRoutes: {
              dw: 'dw_url_mock',
              jsonServer: 'jsonServer_url_mock',
              ng: 'ng_url_mock',
              ngCli: 'ngCli_url_mock'
            },
            itemsPerPage: '5',
            rest: {
              host: 'localhost',
              port: 3000,
              ssl: false,
              basePath: 'api/v1',
              endpoints: {
                carousel: {
                  host: 'localhost',
                  port: 3000,
                  ssl: false,
                  method: 'GET',
                  uri: 'persons/:personType/:personId/carousel'
                },
                beneficiaries: {
                  host: 'localhost',
                  port: 3000,
                  ssl: false,
                  method: 'GET',
                  uri: 'persons/:personType/:personId/beneficiaries',
                  queryParams: [
                    'productId',
                    'subProductId'
                  ]
                },
                customization: {
                  host: 'localhost',
                  port: 3000,
                  ssl: false,
                  method: 'POST',
                  uri: 'persons/customization'
                },
                getSign: {
                  host: "localhost",
                  port: 3000,
                  ssl: false,
                  method: "GET",
                  uri: "persons/getSign",
                  queryParams: [
                    "idExpedient",
                    "name",
                    "document",
                    "language",
                    "signer",
                    "type"
                  ]
                },
                documents: {
                  host: 'localhost',
                  port: 3000,
                  ssl: false,
                  method: 'GET',
                  uri: 'persons/documents'
                },
                getIndPeticion: {
                  host: 'localhost',
                  port: 3000,
                  ssl: false,
                  method: 'GET',
                  uri: 'persons/getIndPeticion',
                  queryParams: [
                    'signatureId'
                  ]
                },
                cancelExp: {
                  host: 'localhost',
                  port: 3000,
                  ssl: false,
                  method: 'PUT',
                  uri: 'persons/cancelExp',
                  queryParams: [
                    'idExpedient'
                  ]
                },
                hire: {
                  host: 'localhost',
                  port: 3000,
                  ssl: false,
                  method: 'POST',
                  uri: 'persons/hire'
                },
                getDocument: {
                  host: 'localhost',
                  port: 3000,
                  ssl: false,
                  method: 'GET',
                  uri: 'persons/getDocument',
                  queryParams: [
                    'gnId',
                    'documentType'
                  ]
                }
              }
            }
          }
        }),
        SecurityTestingModule,
        LoggerTestingModule,
        AngularMaterialModule,
        FakeTestDialogModule
      ],
      providers: [
        SignService,
        SignStatusService,
        DocumentsService,
        { provide: Router, useClass: class { navigate = jasmine.createSpy('navigate'); } }
      ]
    })
      .compileComponents();
  }));

  beforeEach(inject([SignService], (s: any) => {
    signService = s;
    fixture = TestBed.createComponent(SignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  beforeEach(inject([SignStatusService], (s: any) => {
    signStatusService = s;
  }));

  beforeEach(inject([DocumentsService], (s: any) => {
    documentsService = s;
  }));

  it('should create', () => {
    component.appObject = {
      company: {
        companyDocument: '',
        typeCompanyDocument: '',
        companyName: '',
        companyNameCard: '',
        companyUsualAddress: '',
        companyShippingAddress: '',
      },
      office: {
        officeName: '',
        officeLocation: '',
        officeAddress: '',
        officeTeller: ''
      },
      representatives: [],
      localContracts: {
        localContract: {
          contractId: ''
        }
      }
    }
    const response: any[] = [];
    spyOn(documentsService, 'fetchDocuments').and.returnValue(of(response));
    expect(component).toBeTruthy();
  });

  it('should exit', () => {
    component.intervalId = [8, 10];
    component.idExpedient = false;
    expect(component.exit()).toBeUndefined();
  });

  it('should validateSignDocuments true', () => {
    component.allDocumentsSigned = true;
    component.appObject = {
      localContracts: {
        localContract: {
          contractId: ''
        }
      }
    };
    expect(component.validateSignDocuments()).toBeUndefined();
  });

  it('should validateSignDocuments false', () => {
    component.allDocumentsSigned = false;
    component.appObject = {
      localContracts: {
        localContract: {
          contractId: ''
        }
      }
    };
    expect(component.validateSignDocuments()).toBeUndefined();
  });

  it('should handleHire', () => {
    component.allDocumentsSigned = false;
    expect(component.handleHire()).toBeUndefined();
  });

  it('should goBack idExpedient', () => {
    component.intervalId = [8, 10];
    component.idExpedient = '1'
    expect(component.goBack()).toBeUndefined();
  });

  it('should goBack noidExpedient', () => {
    component.intervalId = [8, 10];
    component.appObject = {
      localContracts: {
        localContract: {
          contractId: ''
        }
      }
    }
    expect(component.goBack()).toBeUndefined();
  });

  it('should displayMessage OK', () => {
    const event = {
      data: 'OK'
    }
    const data = {
      documents: [
        {
          gnId: '127639847-aaa-77635699', documentType: 'DEBIT', mandatory: 'S', signers: [
            { personType: 'F', personId: '128139243' },
            { personType: 'F', personId: '1' }
          ]
        },
        {
          gnId: '127639847-aaa-77635698', documentType: 'CUFED', mandatory: 'S', signers: [
            { personType: 'F', personId: '128139243' },
            { personType: 'F', personId: '1' }
          ]
        }
      ]
    }
    const documentsMandatory = [
      {
        documents: [
          {
            buttons: {
              watchIcon: false,
              errorIcon: false,
              signButton: false
            }
          }
        ]
      }
    ]

    component.documentsMandatoryByRepresentative = documentsMandatory;
    component.documentIndex = 0;
    component.signerIndex = 0;
    component.sessionDocumentIndex = 0;
    component.sessionSignerIndex = 0;
    component.appObject = data;
    expect(component.displayMessage(event)).toBeUndefined();
  });

  it('should displayMessage KO', () => {
    const event = {
      data: 'KO'
    }
    const data = {
      documents: [
        {
          gnId: '127639847-aaa-77635699', documentType: 'DEBIT', mandatory: 'S', signers: [
            { personType: 'F', personId: '128139243' },
            { personType: 'F', personId: '1' }
          ]
        },
        {
          gnId: '127639847-aaa-77635698', documentType: 'CUFED', mandatory: 'S', signers: [
            { personType: 'F', personId: '128139243' },
            { personType: 'F', personId: '1' }
          ]
        }
      ]
    }
    const documentsMandatory = [
      {
        documents: [
          {
            buttons: {
              watchIcon: false,
              errorIcon: false,
              signButton: false
            }
          }
        ]
      }
    ]

    component.documentsMandatoryByRepresentative = documentsMandatory;
    component.documentIndex = 0;
    component.signerIndex = 0;
    component.sessionDocumentIndex = 0;
    component.sessionSignerIndex = 0;
    component.appObject = data;
    expect(component.displayMessage(event)).toBeUndefined();
  });

  it('should setMandatoryByRepresentative mandatory N', () => {
    component.documentsMandatoryByRepresentative = [
      {
        personId: '1'
      }
    ];
    const element = {
      mandatory: 'N',
      documentType: '',
      gnId: ''
    }
    const representative = {
      personId: '1',
      name: '',
      personType: '',
      document: ''
    }
    expect(component.setMandatoryByRepresentative(element, representative)).toBeUndefined();
  });

  it('should setMandatoryByRepresentative mandatory S', () => {
    component.documentsMandatoryByRepresentative = [
      {
        personId: '1'
      }
    ];
    const element = {
      mandatory: 'S',
      documentType: '',
      gnId: ''
    }
    const representative = {
      personId: '1',
      name: '',
      personType: '',
      document: ''
    }
    expect(component.setMandatoryByRepresentative(element, representative)).toBeUndefined();
  });

  it('should setMandatoryByRepresentative mandatory', () => {
    component.documentsNoMandatoryByRepresentative = [
      {
        personId: '1',
        documents: []
      }
    ];
    const element = {
      mandatory: 'S',
      documentType: '',
      gnId: ''
    }
    const representative = {
      personId: '1',
      name: '',
      personType: '',
      document: ''
    }
    expect(component.setMandatoryByRepresentative(element, representative)).toBeUndefined();
  });

  it('should handleSignClick', () => {
    const personType = 'F'
    const signerId = '128139243'
    const documentId = 'N-79740380R'
    const documentGnId = '127639847-aaa-77635699'
    const documentIndex = 0
    const signerIndex = 0
    const documentsLength = 1;
    const data = {
      documents: [
        {
          gnId: '127639847-aaa-77635699', documentType: 'DEBIT', mandatory: 'S', signers: [
            { personType: 'F', personId: '128139243' },
            { personType: 'F', personId: '1' }
          ]
        },
        {
          gnId: '127639847-aaa-77635698', documentType: 'CUFED', mandatory: 'S', signers: [
            { personType: 'F', personId: '128139243' },
            { personType: 'F', personId: '1' }
          ]
        }
      ]
    }
    const documentsMandatoryByRepresentative = [
      {
        documents: [
          {
            buttons: {
              errorIcon: false,
              signButton: false,
              tooltipError: ''
            }
          }
        ]
      }
    ]
    component.signRequest = { error: { errorCode: 'test' } }
    component.representatives =
      [{ name: 'MARIO PMG WEB', personType: 'F', personId: '128139243', document: '24185476X', typeDocument: 'N' }]
    component.appObject = data;
    const response: any[] = [];
    spyOn(signService, 'fetchSignUrl').and.returnValue(of(response));
    expect(component.handleSignClick(personType, signerId, documentId, documentGnId, documentIndex, signerIndex, documentsLength)).toBeUndefined();
  });

  it('setIntervalTimes', () => {
    const delay = 2000
    const repetitions = 3
    const sessionDocumentIndex = 0
    const sessionSignerIndex = 0
    const signerIndex = 0
    const documentIndex = 0
    component.idExpedient = '3878019'
    const response: any[] = [];
    spyOn(signStatusService, 'fetchSignStatus').and.returnValue(of(response));
    expect(component.setIntervalTimes(delay, repetitions, sessionDocumentIndex, sessionSignerIndex, signerIndex, documentIndex)).toBeUndefined();
  });

  it('should getInfoSessionStorage', () => {
    component.appObject = {
      localContracts: {
        localContract: {
          contractId: ''
        }
      },
      office: {
        officeId: ''
      },
      company: {
        personId: ''
      }
    }
    expect(component.getInfoSessionStorage()).toBeUndefined();
  });

  it('should handlePrintClick with document', () => {
    const response: any = {
      document: 'difosdsoifusoifdusodifusodf'
    };
    spyOn(documentsService, 'getPdfDocument').and.returnValue(of(response));
    expect(component.handlePrintClick('Prueba', 'Prueba')).toBeUndefined();
  });

  it('should handlePrintClick without document', () => {
    const response: any = '';
    const window = {
      navigator: {
        msSaveOrOpenBlob: ''
      }
    }
    spyOn(documentsService, 'getPdfDocument').and.returnValue(of(response));
    expect(component.handlePrintClick('Prueba', 'Prueba')).toBeUndefined();
  });

  it('successFetchDocuments', () => {
    component.appObject = {
      localContracts: {
        localContract: {
          contractId: ''
        }
      }
    }
    component.representatives = 
      [
        {
          personId: "128139243"
        }
      ]
    const elem: any = {
      documents: [
        {
          documentType: "DEB_TARJETA",
          gnId: "127639847-aaa-77635699",
          mandatory: "S",
          signers: [
            {
              personId: "128139243",
              personType: "F"
            },
            {
              personId: "1",
              personType: "F"
            }
          ]
        },
        {
          documentType: "CUFED",
          gnId: "127639847-aaa-77635698",
          mandatory: "S",
          signers: [
            {
              personId: "128139243",
              personType: "F"
            },
            {
              personId: "1",
              personType: "F"
            }
          ]
        }
      ],
      idExpedient: "3878019",
      partenonPAN: {
        branchId: "1946",
        companyId: "0049",
        contractId: "0001704",
        productId: "501"
      }
    };
    expect(component.successFetchDocuments(elem)).toBeUndefined();
  });
});