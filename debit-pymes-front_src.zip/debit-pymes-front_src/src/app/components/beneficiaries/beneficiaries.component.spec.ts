import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { Router } from '@angular/router';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ConfigTestingModule } from '@ng-darwin/config';
import { LoggerTestingModule } from '@ng-darwin/logger';
import { SecurityTestingModule } from '@ng-darwin/security';

import { BeneficiariesComponent } from './beneficiaries.component';
import { BeneficiariesTableComponent } from './components/table/beneficiaries-table.component';
import { ErrorComponent } from 'src/app/shared/components/error/error.component';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';
import { HeaderComponent } from 'src/app/shared/components/header/header.component';
import { TranslateModule } from '@ngx-translate/core';
import { AngularMaterialModule } from 'src/app/shared/angular-material.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BeneficiariesService } from 'src/app/shared/services/beneficiaries.service';
import { NgModule } from '@angular/core';

@NgModule({
  imports: [],
  declarations: [],
  entryComponents: [ModalComponent]
})
export class FakeTestDialogModule {}

describe('BeneficiariesComponent', () => {
  let component: BeneficiariesComponent;
  let fixture: ComponentFixture<BeneficiariesComponent>;

  beforeEach(async(() => {
    return TestBed.configureTestingModule({
      declarations: [
        BeneficiariesComponent,
        BeneficiariesTableComponent,
        ErrorComponent,
        ModalComponent,
        HeaderComponent
      ],
      imports: [
        BrowserAnimationsModule,
        TranslateModule.forRoot(),
        AngularMaterialModule,
        HttpClientTestingModule,
        ConfigTestingModule.forRoot({
          appKey: 'appKey_mock',
          appName: 'appName_mock',
          app: {
            docRoutes: {
              dw: 'dw_url_mock',
              jsonServer: 'jsonServer_url_mock',
              ng: 'ng_url_mock',
              ngCli: 'ngCli_url_mock'
            },
            itemsPerPage: '5',
            rest: {
              host: 'localhost',
              port: 3000,
              ssl: false,
              basePath: 'api/v1',
              endpoints: {
                carousel: {
                  host: 'localhost',
                  port: 3000,
                  ssl: false,
                  method: 'GET',
                  uri: 'persons/:personType/:personId/carousel'
                },
                beneficiaries: {
                  host: 'localhost',
                  port: 3000,
                  ssl: false,
                  method: 'GET',
                  uri: 'persons/:personType/:personId/beneficiaries',
                  queryParams: [
                    'productId',
                    'subProductId'
                  ]
                },
                customization: {
                  host: 'localhost',
                  port: 3000,
                  ssl: false,
                  method: 'POST',
                  uri: 'persons/customization'
                }
              }
            }
          }
        }),
        SecurityTestingModule,
        LoggerTestingModule,
        FakeTestDialogModule
      ],
      providers: [
        BeneficiariesService,
        {
          provide: Router, useClass: class {
            navigate = jasmine.createSpy('navigate');
            navigateByUrl(url: string) {
              return new Promise((resolve, reject) => {});
            }
          }
        }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BeneficiariesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    component.appObject = {
      office: {
        officeTeller: '',
        officeId: ''
      },
      company: {
        personType: '',
        personId: ''
      },
      localContracts: {
        productId: '',
        subProductId: '',
        productDesc: '',
        localContract: {
          contractId: ''
        },
        partenonContract: {
          companyId: '',
          branchId: '',
          productId: '',
          contractId: ''
        },
        descriptionContract: ''
      },
      representatives: []
    }
    expect(component).toBeTruthy();
  });

  it('should go back link', () => {
    fixture.nativeElement.querySelector('.beneficiaries-buttons-back-link').click();
    expect(component.goBack()).toBeUndefined();
  });

  it('should continue button', () => {
    component.selectedAccount = '';
    component.selectedAccountInfo = {
      name: 'prueba',
      localContract: {
        contractId: '11111'
      },
      partenonContract: {
        companyId: '',
        branchId: '',
        productId: '',
        contractId: ''
      }
    };
    fixture.nativeElement.querySelector('.beneficiaries-buttons-continue-button').click();
    expect(component.validateFields()).toBeUndefined();
  });

  it('should settingSessionStorage', () => {
    component.accountsInfo = [
      {
        name: 'Prueba',
        localContract: {
          contractId: 'ES1231231231234'
        },
        partenonContract: {
          companyId: 'ES12',
          branchId: '0149',
          productId: '2838',
          contractId: '38383'
        }
      }
    ];
    component.appObject = {
      office: {
        officeTeller: '',
        officeId: ''
      },
      company: {
        personType: '',
        personId: ''
      },
      localContracts: {
        productId: '',
        subProductId: '',
        productDesc: '',
        localContract: {
          contractId: ''
        },
        partenonContract: {
          companyId: '',
          branchId: '',
          productId: '',
          contractId: ''
        },
        descriptionContract: ''
      },
      representatives: []
    }
    component.selectedAccount = 'ES1231231231234';
    component.selectedBeneficiaries = [
      {
        name: '',
        personType: '',
        personId: '',
        document: 'prueba',
        typeAttorney: ''
      }
    ];
    expect(component.settingSessionStorage()).toBeUndefined();
  });

  it('should cleanSessionStorage', () => {
    component.appObject = {
      office: {
        officeTeller: '',
        officeId: ''
      },
      company: {
        personType: '',
        personId: ''
      },
      localContracts: {
        productId: '',
        subProductId: '',
        productDesc: '',
        localContract: {
          contractId: ''
        },
        partenonContract: {
          companyId: '',
          branchId: '',
          productId: '',
          contractId: ''
        },
        descriptionContract: ''
      },
      representatives: [
        {
          name: '',
          personType: '',
          personId: '',
          document: '',
          typeDocument: '',
          typeAttorney: ''
        }
      ]
    }
    expect(component.cleanSessionStorage()).toBeUndefined();
  });

  it('should validateFields first option', () => {
    component.selectedAccount = '';
    component.accountsInfo = [
      {
        name: 'Prueba',
        localContract: {
          contractId: 'ES1231231231234'
        },
        partenonContract: {
          companyId: 'ES12',
          branchId: '0149',
          productId: '2838',
          contractId: '38383'
        }
      }
    ];
    component.appObject = {
      office: {
        officeTeller: '',
        officeId: ''
      },
      company: {
        personType: '',
        personId: ''
      },
      localContracts: {
        productId: '',
        subProductId: '',
        productDesc: '',
        localContract: {
          contractId: ''
        },
        partenonContract: {
          companyId: '',
          branchId: '',
          productId: '',
          contractId: ''
        },
        descriptionContract: ''
      },
      representatives: []
    }
    expect(component.validateFields()).toBeUndefined();
  });

  it('should validateFields second option', () => {
    component.selectedAccount = 'eeeeee';
    component.selectedBeneficiaries = [];
    component.appObject = {
      office: {
        officeTeller: '',
        officeId: ''
      },
      company: {
        personType: '',
        personId: ''
      },
      localContracts: {
        productId: '',
        subProductId: '',
        productDesc: '',
        localContract: {
          contractId: ''
        },
        partenonContract: {
          companyId: '',
          branchId: '',
          productId: '',
          contractId: ''
        },
        descriptionContract: ''
      },
      representatives: []
    }
    expect(component.validateFields()).toBeUndefined();
  });

  it('should validateFields thrid option', () => {
    component.selectedAccount = 'eeeeee';
    component.selectedBeneficiaries = [
      {
        prueba: 'prueba'
      },
      {
        prueba: 'prueba'
      },
      {
        prueba: 'prueba'
      },
      {
        prueba: 'prueba'
      },
      {
        prueba: 'prueba'
      },
      {
        prueba: 'prueba'
      },
      {
        prueba: 'prueba'
      },
      {
        prueba: 'prueba'
      },
      {
        prueba: 'prueba'
      },
      {
        prueba: 'prueba'
      }
    ];
    component.accountsInfo = [
      {
        name: 'Prueba',
        localContract: {
          contractId: 'ES1231231231234'
        },
        partenonContract: {
          companyId: 'ES12',
          branchId: '0149',
          productId: '2838',
          contractId: '38383'
        }
      }
    ];
    component.appObject = {
      office: {
        officeTeller: '',
        officeId: ''
      },
      company: {
        personType: '',
        personId: ''
      },
      localContracts: {
        productId: '',
        subProductId: '',
        productDesc: '',
        localContract: {
          contractId: ''
        },
        partenonContract: {
          companyId: '',
          branchId: '',
          productId: '',
          contractId: ''
        },
        descriptionContract: ''
      },
      representatives: []
    }
    expect(component.validateFields()).toBeUndefined();
  });

  it('should validateFields fourth option', () => {
    component.selectedAccount = 'eeeeee';
    component.selectedBeneficiaries = [
      {
        prueba: 'prueba'
      },
      {
        prueba: 'prueba'
      },
      {
        prueba: 'prueba'
      },
      {
        prueba: 'prueba'
      },
      {
        prueba: 'prueba'
      },
      {
        prueba: 'prueba'
      }
    ];
    component.accountsInfo = [
      {
        name: 'Prueba',
        localContract: {
          contractId: 'ES1231231231234'
        },
        partenonContract: {
          companyId: 'ES12',
          branchId: '0149',
          productId: '2838',
          contractId: '38383'
        }
      }
    ];
    component.selectedAccount = 'ES1231231231234';
    component.selectedBeneficiaries = [];
    component.appObject = {
      office: {
        officeTeller: '',
        officeId: ''
      },
      company: {
        personType: '',
        personId: ''
      },
      localContracts: {
        productId: '',
        subProductId: '',
        productDesc: '',
        localContract: {
          contractId: ''
        },
        partenonContract: {
          companyId: '',
          branchId: '',
          productId: '',
          contractId: ''
        },
        descriptionContract: ''
      },
      representatives: []
    }
    expect(component.validateFields()).toBeUndefined();
  });

  it('should reloadComponent', () => {
    component.appObject = {
      office: {
        officeTeller: '',
        officeId: ''
      },
      company: {
        personType: '',
        personId: ''
      },
      localContracts: {
        productId: '',
        subProductId: '',
        productDesc: '',
        localContract: {
          contractId: ''
        },
        partenonContract: {
          companyId: '',
          branchId: '',
          productId: '',
          contractId: ''
        },
        descriptionContract: ''
      },
      representatives: []
    }
    expect(component.reloadComponent()).toBeUndefined();
  });
});
