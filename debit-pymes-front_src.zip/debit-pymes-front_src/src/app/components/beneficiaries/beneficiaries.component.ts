// angular imports
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';

// app services imports
import { BeneficiariesService } from '../../shared/services/beneficiaries.service';
import { SessionStorageService } from '../../shared/services/session-storage.service';

// darwun services imports
import { ConfigService } from '@ng-darwin/config';
import { LoggerService } from '@ng-darwin/logger';

// angular material imports
import { MatDialog } from '@angular/material';

// shared components imports
import { ModalComponent } from '../../shared/components/modal/modal.component';
import { LOGO_URL, CARD_IMAGE_SMALL } from '../../shared/constants/utils.constants';


@Component({
  selector: 'app-beneficiaries',
  templateUrl: './beneficiaries.component.html',
  styleUrls: ['./beneficiaries.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class BeneficiariesComponent implements OnInit {
  // Path images variables
  public logoUrl = LOGO_URL;
  public cardImage = CARD_IMAGE_SMALL;

  // sessionStorage variables
  public appObject!: any;
  public cardDescription!: string;
  public branchUser!: string;
  public branchCode!: string;
  public personId!: string;
  public personType!: string;
  public productId!: string;
  public subProductId!: string;
  public representatives!: any[];

  // Manage the error variables
  public isError = false;
  public errorMessage!: string;
  public errorMessageSecondLine!: string;

  // Beneficiaries info variables
  public accountsInfo: any[] = [];
  public beneficiariesInfo: any[] = [];
  public selectedBeneficiaries: any[] = [];
  public selectedAccount!: string;
  public itemsPerPage: any;

  public selectedAccountInfo!: any;

  public selectedCode!: string;

  constructor(
    private readonly router: Router,
    private readonly beneficiariesService: BeneficiariesService,
    private readonly sessionStorageService: SessionStorageService,
    private readonly dialog: MatDialog,
    private readonly configService: ConfigService,
    private readonly loggerService: LoggerService
  ) { }

  ngOnInit() {
    // If session storage is empty, go to the first page
    if(!sessionStorage.getItem('appObject')){
      this.router.navigate(['/cards']);
    }

    // Scroll to the top of the page
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });

    // Get the info from sessionStorage
    this.getInfoSessionStorage();

    // Set the account in the accounts combo
    this.selectedAccount = this.selectedCode;

    // Get the beneficiaries and acount info from the beneficiaries service
    this.beneficiariesService.fetchBeneficiariesAndAccountInfo(
      this.personId, this.personType, this.productId, this.subProductId
    ).subscribe({
      next: (response: any) => {
        if(response.error && response.error.errorCode){
          // If the service get an errorCode, the ErrorComponent is shown with the message
          this.isError= true;
          this.errorMessage= response.error.errorCode;
          this.errorMessageSecondLine = response.error.errorDesc;
        } else {
          // Get the info from the service filter by accounts with balance
          this.accountsInfo = this.beneficiariesService.filterAccountsWithoutBalance(response.localContracts);
          // Get the beneficiaries data
          this.beneficiariesInfo = response.representatives;
          // Initialize beneficiaries checkbox to false
          this.beneficiariesInfo = this.beneficiariesService.initializeUncheckedRepresentatives(this.beneficiariesInfo);
          // If exist representatives on sessionStorage, check de checkbox of this representatives in the table
          if(this.representatives){
            this.representatives.forEach(element=> {
              if(this.beneficiariesInfo.find(beneficiarie => beneficiarie.name === element.name)) {
                this.beneficiariesInfo.find(beneficiarie => beneficiarie.name === element.name).checked = true;
              }
            });
          }
        }
      },
      error: (error: any) => {
        // If the services get a http error, the ErrorComponent is shown and is log in Kibana
        this.isError= true;
        this.errorMessage= 'beneficiariesServiceError';
        this.loggerService.logError({
          log: error,
          component: 'BeneficiariesComponent'
        });
      }
    });
    // Set the items per page in the table component
    this.itemsPerPage = this.configService.config.app.itemsPerPage;
  }

  /**
   * Get the sessionStorage info
   */
  getInfoSessionStorage() {
    this.appObject = this.sessionStorageService.getSessionStorage();
    if (this.appObject.localContracts &&
      this.appObject.localContracts.localContract &&
      this.appObject.office &&
      this.appObject.company &&
      this.appObject.representatives) {
        this.cardDescription = this.appObject.localContracts.productDesc;
        this.branchUser = this.appObject.office.officeTeller;
        this.branchCode = this.appObject.office.officeId;
        this.personId = this.appObject.company.personId;
        this.personType = this.appObject.company.personType;
        this.productId = this.appObject.localContracts.productId;
        this.subProductId = this.appObject.localContracts.subProductId;
        this.selectedCode = this.appObject.localContracts.localContract.contractId;
        this.representatives = this.appObject.representatives;
    }
  }

  /**
   * Go to the previous page
   */
  goBack() {
    // Send all the query params the cards page need
    this.router.navigate(['cards'], { queryParams: {
        branchUser: this.branchUser,
        branchCode: this.branchCode,
        personId: this.personId,
        personType: this.personType,
        back: 'y'
      }
    });
  }

  /**
   * Check the checkbox event in beneficiaries table
   */
  getSelectedBeneficiaries(event: any[]){
    this.selectedBeneficiaries = event;
  }

  /**
   * Select an option event in accounts combobox
   */
  getSelectedAccount(event: any){
    this.selectedAccount = event.value;
  }

  /**
   * Refresh the current component
   */
  reloadComponent() {
    // Clean the sessionStorage
    this.cleanSessionStorage();
    // Reload the component
    this.router.navigateByUrl('/RefreshComponent', { skipLocationChange: true }).then(() => {
      this.router.navigate(['/beneficiaries']);
    });
  }

  /**
   * The application controls if there are more than 9 selected beneficiaries, if there are any selected
   * beneficiaries and if there is a selected account. If not, redirect to the next page
   */
  validateFields() {
    if ( this.selectedAccount.length === 0 ) {
      this.openModal('associatedAccountMandatoryField');
    } else if (this.selectedBeneficiaries.length === 0) {
      this.openModal('beneficiariesMandatoryField');
    } else if (this.selectedBeneficiaries.length > 9) {
      this.openModal('nineMaximumSelectedBeneficiaries');
    } else {
      // Set the selected info in the sessionStorage
      this.settingSessionStorage();
      // Go to customization page
      this.router.navigate(['/customization']);
    }
  }

  /**
   * Open the modal window
   *
   * @param {string} bodyText Paremeter with the text of the modal body
   */
  openModal (bodyText: string) {
    this.dialog.open(ModalComponent, {
      data: {
        title: 'warning',
        bodyText
      }
    });
  }

  /**
   * Set the info in the sessionStorage
   */
  settingSessionStorage() {
    // Save all the variables in a object
    this.selectedAccountInfo = this.accountsInfo.filter(
      accountInfo => accountInfo.localContract.contractId === this.selectedAccount
    )[0];
    if(this.appObject.localContracts) {
      this.appObject.localContracts.localContract.contractId = this.selectedAccountInfo.localContract.contractId;
      this.appObject.localContracts.partenonContract.companyId = this.selectedAccountInfo.partenonContract.companyId;
      this.appObject.localContracts.partenonContract.branchId = this.selectedAccountInfo.partenonContract.branchId;
      this.appObject.localContracts.partenonContract.productId = this.selectedAccountInfo.partenonContract.productId;
      this.appObject.localContracts.partenonContract.contractId = this.selectedAccountInfo.partenonContract.contractId;
      this.appObject.localContracts.descriptionContract = this.selectedAccountInfo.name;
    }
    this.appObject.representatives = [];
    this.selectedBeneficiaries.forEach((element, i) => {
      this.appObject.representatives[i] = {};
      this.appObject.representatives[i].name = element.name;
      this.appObject.representatives[i].personType = element.personType;
      this.appObject.representatives[i].personId = element.personId;
      this.appObject.representatives[i].document = element.document.substring(2);
      this.appObject.representatives[i].typeDocument = element.document.substring(0, 1);
      this.appObject.representatives[i].typeAttorney = element.typeAttorney;
    });
    // Save the variables in sessionStorage
    this.sessionStorageService.setSessionStorage(this.appObject);
  }

  // Clean the sessionStorage info
  cleanSessionStorage() {
    // Clean all the sessionStorage variables
    if(this.appObject.localContracts.localContract) {
      this.appObject.localContracts.localContract.contractId = '';
    }
    if(this.appObject.localContracts.partenonContract) {
      this.appObject.localContracts.partenonContract.companyId = '';
      this.appObject.localContracts.partenonContract.branchId = '';
      this.appObject.localContracts.partenonContract.productId = '';
      this.appObject.localContracts.partenonContract.contractId = '';

    }
    this.appObject.localContracts.descriptionContract = '';
    this.appObject.representatives = [];
    // Save the variables in sessionStorage
    this.sessionStorageService.setSessionStorage(this.appObject);
  }
}
