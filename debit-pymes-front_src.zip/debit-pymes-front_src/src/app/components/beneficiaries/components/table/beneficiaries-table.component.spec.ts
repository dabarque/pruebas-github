import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BeneficiariesTableComponent } from './beneficiaries-table.component';
import { TranslateModule } from '@ngx-translate/core';
import { AngularMaterialModule } from 'src/app/shared/angular-material.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('BeneficiariesTableComponent', () => {
  let component: BeneficiariesTableComponent;
  let fixture: ComponentFixture<BeneficiariesTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BeneficiariesTableComponent ],
      imports: [
        BrowserAnimationsModule,
        TranslateModule.forRoot(),
        AngularMaterialModule ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BeneficiariesTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should checkbox checked', () => {
    fixture.nativeElement.querySelector('.checkAndUncheckCheckbox').click();
    expect(component.selectUnselect()).toBeUndefined();
  })

  it('should beneficiary checkbox checked', () => {
    const event = { checked: true };
    expect(component.checkboxSelect(event)).toBeUndefined();
  })

  it('should beneficiary checkbox unchecked', () => {
    const event = { checked: false };
    expect(component.checkboxSelect(event)).toBeUndefined();
  })
});
