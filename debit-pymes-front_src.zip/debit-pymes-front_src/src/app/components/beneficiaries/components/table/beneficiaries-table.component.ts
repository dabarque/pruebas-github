// angular imports
import { Component, OnInit, ViewChild, Input, OnChanges, Output, EventEmitter } from '@angular/core';

// angular material imports
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';

@Component({
  selector: 'app-beneficiaries-table',
  templateUrl: './beneficiaries-table.component.html'
})

export class BeneficiariesTableComponent implements OnInit, OnChanges {
  @Input() beneficiariesInfo: any[] = [];
  @Input() itemsPerPage!: string;
  @Output() selectedBeneficiaries = new EventEmitter<any[]>();

  // Selected elements table
  public selectedElements: any[] = [];

  // Angular Material variables
  public displayedColumns: string[] = ['checkbox', 'name', 'document'];
  public dataSource!: MatTableDataSource<any>;

  // Checkbock control check variable
  public checked = false;

  // Table sort variable
  @ViewChild(MatSort, { static: true })
  sort!: MatSort;

  // Table paginator variable
  @ViewChild(MatPaginator, { static: true })
  paginator!: MatPaginator;

  constructor() { }

  ngOnInit() {
  }

  /**
   *  Initializes the table, the paginator and the sort component
   */
  ngOnChanges() {
    this.dataSource = new MatTableDataSource(this.beneficiariesInfo);
    this.dataSource.sort = this.sort;
    this.paginator._intl.nextPageLabel = '';
    this.paginator._intl.previousPageLabel = '';
    this.paginator._intl.itemsPerPageLabel = '';
    this.paginator._intl.firstPageLabel = '';
    this.paginator._intl.lastPageLabel = '';
    this.dataSource.paginator = this.paginator;
    this.beneficiariesInfo.forEach(element => {
      if (element.checked) {
        this.selectedElements.push(element);
      }
    });
    this.selectedBeneficiaries.emit(this.selectedElements);
  }

  /**
   * Checkbox check event. The info of the beneficiary selected is add to the selected beneficiaries list
   *
   * @param {*} event Checkbox check event
   */
  checkboxSelect(event: any) {
    // If the checkbox is checked, the info is saved
    if (event.checked) {
      this.selectedElements.push(
        this.beneficiariesInfo.filter(beneficiary => beneficiary.name === event.source.value)[0]
      );
    } else {
      this.selectedElements = this.selectedElements.filter(beneficiary => beneficiary.name !== event.source.value);
    }
    this.beneficiariesInfo.filter(beneficiary => beneficiary.name === event.source.value)[0].checked = event.checked;
    // Emit the info saved to the parent component
    this.selectedBeneficiaries.emit(this.selectedElements);
  }

  /**
   * Check all the checkbox in the table or uncheck all the checkbox in the table
   */
  selectUnselect() {
    // If the checkbox is checked, all the checkbox are checked and their info saved
    if (this.checked) {
      this.checked = false;
      this.selectedElements = [];
      this.beneficiariesInfo.forEach(element => {
        element.checked = false;
      })
      // If the checkbox is unchecked, all the checkbox are unchecked and their info cleared
    } else {
      this.checked = true;
      this.selectedElements = this.beneficiariesInfo.filter(result => (
        result.state === 'OK'
      ));
    }
    // Emit the info saved to the parent component
    this.selectedBeneficiaries.emit(this.selectedElements);
  }
}
