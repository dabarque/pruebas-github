import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Router, ActivatedRoute } from '@angular/router';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ConfigTestingModule } from '@ng-darwin/config';
import { LoggerTestingModule } from '@ng-darwin/logger';
import { SecurityTestingModule } from '@ng-darwin/security';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { CustomizationComponent } from './customization.component';
import { CustomizationTableComponent } from './components/table/customization-table.component';
import { ErrorComponent } from 'src/app/shared/components/error/error.component';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';
import { HeaderComponent } from 'src/app/shared/components/header/header.component';
import { TranslateModule } from '@ngx-translate/core';
import { AngularMaterialModule } from 'src/app/shared/angular-material.module';
import { CustomizationService } from 'src/app/shared/services/customization.service';
import { SessionStorageService } from 'src/app/shared/services/session-storage.service';
import { NgModule } from '@angular/core';
import { Observable } from 'rxjs';
import { element } from 'protractor';

@NgModule({
  imports: [],
  declarations: [],
  entryComponents: [ModalComponent]
})
export class FakeTestDialogModule { }

describe('CustomizationComponent', () => {
  let component: CustomizationComponent;
  let fixture: ComponentFixture<CustomizationComponent>;

  class ActivatedRouteMock {
    queryParams = new Observable(observer => {
      const urlParams = {
        branchCode: '0149',
        branchUser: 'xe18738',
        personId: '12929292',
        personType: 'J',
        back: 'n'
      }
      observer.next(urlParams);
      observer.complete();
    });
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        CustomizationComponent,
        CustomizationTableComponent,
        ErrorComponent,
        ModalComponent,
        HeaderComponent
      ],
      imports: [
        BrowserAnimationsModule,
        TranslateModule.forRoot(),
        AngularMaterialModule,
        HttpClientTestingModule,
        ConfigTestingModule.forRoot({
          appKey: 'appKey_mock',
          appName: 'appName_mock',
          app: {
            docRoutes: {
              dw: 'dw_url_mock',
              jsonServer: 'jsonServer_url_mock',
              ng: 'ng_url_mock',
              ngCli: 'ngCli_url_mock'
            },
            itemsPerPage: '5',
            rest: {
              host: 'localhost',
              port: 3000,
              ssl: false,
              basePath: 'api/v1',
              endpoints: {
                carousel: {
                  host: 'localhost',
                  port: 3000,
                  ssl: false,
                  method: 'GET',
                  uri: 'persons/:personType/:personId/carousel'
                },
                beneficiaries: {
                  host: 'localhost',
                  port: 3000,
                  ssl: false,
                  method: 'GET',
                  uri: 'persons/:personType/:personId/beneficiaries',
                  queryParams: [
                    'productId',
                    'subProductId'
                  ]
                },
                customization: {
                  host: 'localhost',
                  port: 3000,
                  ssl: false,
                  method: 'POST',
                  uri: 'persons/customization'
                }
              }
            }
          }
        }),
        SecurityTestingModule,
        LoggerTestingModule,
        FakeTestDialogModule
      ],
      providers: [
        SessionStorageService,
        CustomizationService,
        {
          provide: Router, useClass: class {
            navigate = jasmine.createSpy('navigate');
            navigateByUrl(url: string) {
              return new Promise((resolve, reject) => { });
            }
          }
        },
        { provide: ActivatedRoute, useClass: ActivatedRouteMock }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomizationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    component.appObject = {
      company: {
        companyDocument: '',
        typeCompanyDocument: '',
        companyName: '',
        companyNameCard: '',
        companyUsualAddress: '',
        companyShippingAddress: '',
      },
      office: {
        officeName: '',
        officeLocation: '',
        officeAddress: '',
        officeTeller: ''
      },
      representatives: []
    }
    expect(component).toBeTruthy();
  });

  it('should go back link', () => {
    component.appObject = {
      company: {
        companyDocument: '',
        typeCompanyDocument: '',
        companyName: '',
        companyNameCard: '',
        companyUsualAddress: '',
        companyShippingAddress: '',
      },
      office: {
        officeName: '',
        officeLocation: '',
        officeAddress: '',
        officeTeller: ''
      },
      representatives: []
    }
    expect(component.goBack()).toBeUndefined();
  });

  it('should validateFields', () => {
    component.appObject = {
      company: {
        companyDocument: '',
        typeCompanyDocument: '',
        companyName: '',
        companyNameCard: '',
        companyUsualAddress: '',
        companyShippingAddress: '',
        companyAddresses: []
      },
      office: {
        officeName: '',
        officeLocation: '',
        officeTeller: ''
      },
      representatives: []
    }
    expect(component.validateFields()).toBeUndefined();
  });

  it('should validateFields first option', () => {
    component.selectedCompanyName = ' ';
    component.appObject = {
      company: {
        companyDocument: '',
        typeCompanyDocument: '',
        companyName: '',
        companyNameCard: '',
        companyUsualAddress: '',
        companyShippingAddress: '',
        companyAddresses: []
      },
      office: {
        officeName: '',
        officeLocation: '',
        officeTeller: ''
      },
      representatives: []
    }
    expect(component.validateFields()).toBeUndefined();
  });

  it('should validateFields second option', () => {
    component.selectedCompanyName = 'prueba';
    component.appObject = {
      company: {
        companyDocument: '',
        typeCompanyDocument: '',
        companyName: '',
        companyNameCard: '',
        companyUsualAddress: '',
        companyShippingAddress: '',
        companyAddresses: []
      },
      office: {
        officeName: '',
        officeLocation: '',
        officeTeller: ''
      },
      representatives: []
    }
    expect(component.validateFields()).toBeUndefined();
  });

  it('should validateFields thrid option', () => {
    component.selectedCompanyName = 'prueba';
    component.selectedAddress = 'prueba';
    component.selectedTypeHolderCommunicationsAdress = '';
    expect(component.validateFields()).toBeUndefined();
  });

  it('should validateFields fourth option', () => {
    component.selectedCompanyName = 'prueba';
    component.selectedAddress = 'prueba';
    component.selectedTypeHolderCommunicationsAdress = 'prueba';
    component.appObject = {
      localContracts: {
        productDesc: '',
        productId: '',
        subProductId: '',
      },
      company: {
        companyDocument: '',
        typeCompanyDocument: '',
        companyName: '',
        companyNameCard: '',
        companyUsualAddress: '',
        companyShippingAddress: ''
      },
      office: {
        officeName: '',
        officeLocation: '',
        officeAddress: ''
      },
      representatives: [
        {
          personNameCard: '',
          shippingAddress: '',
          usualAddress: '',
          cesPhone: '',
          preferredPhone: '',
          ces: '',
          preferredEmail: '',
          document: '11111'
        }
      ]
    };
    component.customizationInfo = {
      companyName: 'prueba',
      companyDocument: 'prueba',
      typeCompanyDocument: 'prueba',
      officeName: 'prueba',
      officeLocation: 'prueba',
      officeAddresses: [
        {
          address: 'prueba',
          addressType: '1'
        },
        {
          address: 'prueba',
          addressType: '2'
        }
      ]
    };
    component.companyAddressInfo = [
      {
        address: 'prueba',
        addressType: '1'
      }
    ];
    component.selectedDataFromTable = [
      {
        document: '11111',
        beneficiary: 'Prueba',
        deliveryAddress: '',
        phoneCesAssociated: '',
        ces: ''
      }
    ];
    component.representativeList = [
      {
        document: '11111',
        deliveryAddress: [
          {
            address: 'prueba',
            addressType: '1'
          }
        ],
        phoneCesAssociated: [
          {
            number: '38383883',
            order: '1'
          }
        ],
        emails: [
          {
            email: 'afdf@bad.com',
            type: 'S'
          }
        ]
      }
    ];
    expect(component.validateFields()).toBeUndefined();
  });

  it('should validateFields fifth option bis', () => {
     component.selectedDataFromTable = [
      {
        document: '11111',
        beneficiary: ' ',
        deliveryAddress: '',
        phoneCesAssociated: '',
        ces: ''
      }
    ];
    expect(component.validateFields()).toBeUndefined();
  });

  it('should validateFields fifth option', () => {
    component.selectedCompanyName = 'prueba';
    component.companyName = 'prueba';
    expect(component.validateFields()).toBeUndefined();
  });

  it('should setSessionStorageInfo', () => {
    component.appObject = {
      localContracts: {
        productDesc: '',
        productId: '',
        subProductId: '',
      },
      company: {
        companyDocument: '',
        typeCompanyDocument: '',
        companyName: '',
        companyNameCard: '',
        companyUsualAddress: '',
        companyShippingAddress: ''
      },
      office: {
        officeName: '',
        officeLocation: '',
        officeAddress: ''
      },
      representatives: [
        {
          personNameCard: '',
          shippingAddress: '',
          usualAddress: '',
          cesPhone: '',
          preferredPhone: '',
          ces: '',
          preferredEmail: '',
          document: '11111'
        }
      ]
    };
    component.customizationInfo = {
      companyName: 'prueba',
      companyDocument: 'prueba',
      typeCompanyDocument: 'prueba',
      officeName: 'prueba',
      officeLocation: 'prueba',
      officeAddresses: [
        {
          address: 'prueba',
          addressType: '1'
        },
        {
          address: 'prueba',
          addressType: '2'
        }
      ],
      companyEmails: [],
      companyPhones: []
    };
    component.companyAddressInfo = [
      {
        address: 'prueba',
        addressType: '1'
      }
    ];
    component.selectedDataFromTable = [
      {
        document: '11111',
        beneficiary: 'Prueba',
        deliveryAddress: '',
        phoneCesAssociated: '',
        ces: ''
      }
    ];
    component.representativeList = [
      {
        document: '11111',
        deliveryAddress: [
          {
            address: 'prueba',
            addressType: '1'
          }
        ],
        phoneCesAssociated: [
          {
            number: '38383883',
            order: '1'
          }
        ],
        emails: [
          {
            email: 'afdf@bad.com',
            type: 'S'
          }
        ]
      }
    ];
    component.selectedTypeHolderCommunicationsAdress = '1';
    expect(component.setSessionStorageInfo()).toBeUndefined();
  })
  
  it('should setSessionStorageInfo', () => {
    component.selectedTypeHolderCommunicationsAdress = '1';
    expect(component.setSessionStorageInfo()).toBeUndefined();
  })

  it('setUserInfo', () => {
    const data = {
      personNameCard: '',
      document: '1',
      personId: '1',
      shippingAddress: '',
      sex: '',
      usualAddress: '',
      cesPhone: '',
      preferredPhone: '',
      ces: '',
      preferredEmail: ''
    };
    component.selectedDataFromTable = [
      {
        document: '1',
        personId: '1',
        beneficiary: 'beneficiary',
        deliveryAddress: '',
        ces: 'ces',
        phoneCesAssociated: ''
      }
    ]
    component.customizationInfo = {
      representatives: [
        {
          personId: '1',
          sex: 'V'
        }
      ]
    }
    component.representativeList = [
      {
        document: '1',
        phoneCesAssociated: [{}],
        emails: ''
      }
    ]
    expect(component.setUserInfo(data)).toBeUndefined();
  });

  it('should cleanSessionStorage', () => {
    component.appObject = {
      localContracts: {
        productDesc: '',
        productId: '',
        subProductId: '',
      },
      company: {
        companyDocument: '',
        typeCompanyDocument: '',
        companyName: '',
        companyNameCard: '',
        companyUsualAddress: '',
        companyShippingAddress: ''
      },
      representatives: [
        {
          personNameCard: '',
          shippingAddress: '',
          usualAddress: '',
          cesPhone: '',
          preferredPhone: '',
          ces: '',
          preferredEmail: ''
        }
      ]
    };
    expect(component.cleanSessionStorage()).toBeUndefined();
  })

  it('getSelectedAddress OK', () => {
    const event = { value: 'CALLE MAYOR 3, 3098, 28037, MADRID, MADRID, ESPAÑA' }
    component.selectedTypeHolderCommunicationsAdress = '1'
    expect(component.getSelectedAddress(event)).toBeUndefined();
  })

  it('getSelectedAddress KO', () => {
    const event = { value: 'CALLE MAYOR 3, 3098, 28037, MADRID, MADRID, ESPAÑA' }
    component.selectedTypeHolderCommunicationsAdress = ''
    expect(component.getSelectedAddress(event)).toBeUndefined();
  })

  it('getSelectedHolderCommunicationsAdress 3', () => {
    const event = { value: '3' }
    component.officeAddressInfo = [
      { address: 'ESQUINA ABANICO, 3, 28037, MADRID, MADRID, ESPAÑA', addressType: '1' },
      { address: 'CALLE ABANICO, 3, 28037, MADRID, MADRID, ESPAÑA', addressType: '4' }
    ]
    component.selectedDataFromTable = [
      {
        document: '11111',
        beneficiary: 'Prueba',
        deliveryAddress: '',
        phoneCesAssociated: '',
        ces: ''
      }
    ]
    expect(component.getSelectedHolderCommunicationsAdress(event)).toBeUndefined();
  })

  it('getSelectedHolderCommunicationsAdress 3', () => {
    const event = { value: '3' }
    component.officeAddressInfo = [
      { address: 'ESQUINA ABANICO, 3, 28037, MADRID, MADRID, ESPAÑA', addressType: '1' },
      { address: 'CALLE ABANICO, 3, 28037, MADRID, MADRID, ESPAÑA', addressType: '4' }
    ]
    expect(component.getSelectedHolderCommunicationsAdress(event)).toBeUndefined();
  })

  it('getSelectedHolderCommunicationsAdress 1', () => {
    const event = { value: '1' }
    component.officeAddressInfo = [
      { address: 'ESQUINA ABANICO, 3, 28037, MADRID, MADRID, ESPAÑA', addressType: '1' },
      { address: 'CALLE ABANICO, 3, 28037, MADRID, MADRID, ESPAÑA', addressType: '4' }
    ]
    component.selectedDataFromTable = [
      {
        document: '11111',
        beneficiary: 'Prueba',
        deliveryAddress: '',
        phoneCesAssociated: '',
        ces: ''
      }
    ]
    expect(component.getSelectedHolderCommunicationsAdress(event)).toBeUndefined();
  })

  it('getSelectedHolderCommunicationsAdress 1', () => {
    const event = { value: '1' }
    component.officeAddressInfo = [
      { address: 'ESQUINA ABANICO, 3, 28037, MADRID, MADRID, ESPAÑA', addressType: '1' },
      { address: 'CALLE ABANICO, 3, 28037, MADRID, MADRID, ESPAÑA', addressType: '4' }
    ]
    expect(component.getSelectedHolderCommunicationsAdress(event)).toBeUndefined();
  })

  it('getSelectedHolderCommunicationsAdress', () => {
    const event = { value: '' }
    expect(component.getSelectedHolderCommunicationsAdress(event)).toBeUndefined();
  })

  it('getCustomizationInfo', () => {
    expect(component.getCustomizationInfo()).toBeUndefined();
  })

  it('getRepresentativesTableInfo', () => {
    component.representatives = 
      [
        {
          personId: '128139243'
        }
      ]
    const representatives = 
      [
        {
          name: 'MARIO PMG WEB',
          personType: 'F',
          personId: '128139243',
          document: '24185476X',
          typeDocument: 'N',
          addresses: {
            address: '',
            addressFormat: '12',
            addressType: '02',
            order: '2'
          },
          phones: 
            [
              { 
                number: '2342' 
              }, 
              { 
                number: '2322' 
              }
            ]
        }]
    expect(component.getRepresentativesTableInfo(representatives)).toBeUndefined();
  })

  it('handleStorageAddress', () => {
    const element = { personId: '128139243' }
    component.appObject = {
      representatives:
        [
          {
            name: 'MARIO PMG WEB',
            personType: 'F',
            personId: '128139243',
            document: '24185476X',
            typeDocument: 'N',
            shippingAddress: {
              address: '',
              addressFormat: '12',
              addressType: '02',
              order: '2'
            }
          }]
    }
    expect(component.handleStorageAddress(element)).toBe('');
  })

  it('handleStoragePhone', () => {
    const element = { personId: '128139243' }
    const newLocal = '984267152';
    component.appObject =
    {
      representatives:
        [
          {
            name: 'MARIO PMG WEB',
            personType: 'F',
            personId: '128139243',
            document: '24185476X',
            typeDocument: 'N',
            cesPhone: { number: newLocal }
          }
        ]
    }
    expect(component.handleStoragePhone(element)).toBe('984267152');
  });

  it('handleStorageCes', () => {
    const element = { personId: '128139243', phones: [{ number: '2342' }, { number: '2322' }] }
    component.appObject =
    {
      representatives:
        [
          {
            name: 'MARIO PMG WEB',
            personType: 'F',
            personId: '128139243',
            document: '24185476X',
            typeDocument: 'N'
          }
        ]
    }
    expect(component.handleStorageCes(element)).toBe(true);
  });

  it('should reloadComponent', () => {
    component.appObject = {
      company: {},
      representatives: [{}]
    };
    expect(component.reloadComponent()).toBeUndefined();
  });

  it('should changeCompanyName', () => {
    const event = {
      target: {
        value: 'prueba'
      }
    };
    expect(component.changeCompanyName(event)).toBeUndefined();
  });

  it('should getSelectedBeneficiaries', () => {
    const event: any[] = [];
    expect(component.getSelectedBeneficiaries(event)).toBeUndefined();
  });
  
   it('should postValidationAddressCompany vacio', () => {
     component.appObject = {
      company: {
		    companyUsualAddress: {
			   order: ''
		   }			  
	    }
	  };
    expect(component.postValidationAddressCompany()).toBeUndefined();
  });
    
   it('should postValidationAddressCompany lleno', () => {
     component.appObject = {
      company: {
		    companyUsualAddress: {
			    order: '1234'
		    }			  
	    }
	  };
    expect(component.postValidationAddressCompany()).toBeUndefined();
  });
  
   it('should postValidationAddressHolders vacio', () => {
    component.appObject = {
      representatives: [
        {
          shippingAddress: {
			        order: ''
		      },			  
          usualAddress: {
			        order: ''
		      }			  
        }
      ]
    };   
    expect(component.postValidationAddressHolders()).toBeUndefined();
  });
  
   it('should postValidationAddressHolders lleno', () => {
    component.appObject = {
      representatives: [
        {
          shippingAddress: {
			        order: '1234'
		      },			  
          usualAddress: {
			        order: '1234'
		      }
        }
      ]
    };   
    expect(component.postValidationAddressHolders()).toBeUndefined();
  });
  
  it('checkUsualAndShippingAddress', () => {
    component.appObject = {
      company: {
        companyDocument: "R3878019C",
        companyName: "S.Q. Resine Italia",
        companyNameCard: "S.Q. Resine Italia",
        companyShippingAddress: { address: "CALLE EMPRESA, 3098, 28037, MADRID, MADRID, ESPAÑA", addressType: "01", addressFormat: "11", order: "1" },
        companyUsualAddress: { address: "CALLE EMPRESA, 3098, 28037, MADRID, MADRID, ESPAÑA", addressType: "01", addressFormat: "11", order: "1" },
        personId: "12929292",
        personType: "J",
        typeCompanyDocument: "S"
      }
    };
    expect(component.checkUsualAndShippingAddress()).toBeUndefined();
  });

  it('checkUsualAndShippingAddress', () => {
    component.companyAddressInfo = [{ address: "CALLE EMPRESA, 3098, 28037, MADRID, MADRID, ESPAÑA", addressType: "01", addressFormat: "11", order: "1" }];
    component.appObject = {
      company: {
        companyDocument: "R3878019C",
        companyName: "S.Q. Resine Italia",
        companyNameCard: "S.Q. Resine Italia",
        companyShippingAddress: {},
        companyUsualAddress: {},
        personId: "12929292",
        personType: "J",
        typeCompanyDocument: "S"
      }
    };
    expect(component.checkUsualAndShippingAddress()).toBeUndefined();
  });

  it('getTypeOneOrFirst', () => {
    const list = [
      {
        address: "AQUI LA CALLE",
        addressFormat: "12",
        addressType: null,
        order: "2"
      },
      {
        address: "AQUI LA CALLE 2",
        addressFormat: "12",
        addressType: "01",
        order: "2"
      }
    ];
    const param = 'addressType';
    expect(component.getTypeOneOrFirst(list, param)).toBeUndefined();
  });
});
