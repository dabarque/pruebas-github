import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomizationTableComponent } from './customization-table.component';
import { TranslateModule } from '@ngx-translate/core';
import { AngularMaterialModule } from 'src/app/shared/angular-material.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


describe('CustomizationTableComponent', () => {
  let component: CustomizationTableComponent;
  let fixture: ComponentFixture<CustomizationTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CustomizationTableComponent],
      imports: [
        BrowserAnimationsModule,
        TranslateModule.forRoot(),
        AngularMaterialModule
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomizationTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should enableDisablePhonesSelect true', () => {
    const event = {
      checked: true,
      source: {
        value: 0
      }
    };
    component.disableCombo = [
      {
        disable: true
      }
    ];
    component.representativeList = [{
      sessionStorageCes: false
    }];
    expect(component.enableDisablePhonesSelect(event)).toBeUndefined();
  });

  it('should enableDisablePhonesSelect false', () => {
    const event = {
      checked: false,
      source: {
        value: 0
      }
    };
    component.disableCombo = [
      {
        disable: true
      }
    ];
    component.representativeList = [{
      sessionStorageCes: false
    }];
    expect(component.enableDisablePhonesSelect(event)).toBeUndefined();
  });

  it('should changeBeneficiaryName', () => {
    const event = {
      target: {
        value: 'Prueba'
      }
    }
    component.dataTableChanged = [
      {
        document: '111111111',
        beneficiary: ''
      }
    ];
    expect(component.changeBeneficiaryName(event, '111111111')).toBeUndefined();
  });

  it('should changeDeliveryAddress', () => {
    const event = {
      target: {
        value: 'Prueba'
      }
    }
    component.auxArray = [
      {
        document: '111111111',
        address: 'Prueba',
        deliveryAddress: [
          {
            address: 'Prueba'
          }
        ]
      }
    ];
    component.dataTableChanged = [
      {
        document: '111111111',
        beneficiary: '',
        deliveryAddress: ''
      }
    ];
    expect(component.changeDeliveryAddress(event, '111111111')).toBeUndefined();
  });

  it('should changeCes true', () => {
    const event = {
      checked: true
    }
    component.dataTableChanged = [
      {
        document: '111111111',
        beneficiary: '',
        deliveryAddress: '',
        ces: ''
      }
    ];
    expect(component.changeCes(event, '111111111')).toBeUndefined();
  });

  it('should changeCes false', () => {
    const event = {
      checked: false
    }
    component.dataTableChanged = [
      {
        document: '111111111',
        beneficiary: '',
        deliveryAddress: '',
        ces: '',
        phoneCesAssociated: ''
      }
    ];
    expect(component.changeCes(event, '111111111')).toBeUndefined();
  });

  it('should changePhone false', () => {
    const event = {
      value: 'prueba'
    }
    component.dataTableChanged = [
      {
        document: '111111111',
        beneficiary: '',
        deliveryAddress: '',
        ces: '',
        phoneCesAssociated: ''
      }
    ];

    component.auxArray = [
      {
        document: '111111111',
        address: 'Prueba',
        phoneCesAssociated: [
          {
            number: 'Prueba'
          }
        ]
      }
    ];
    expect(component.changePhone(event, '111111111')).toBeUndefined();
  });

  it('checkSessionStorage', () => {
    const element = {
      beneficiary: "MARIO PMG WEBÑ",
      ces: true,
      deliveryAddress: [
        {
          address: "CALLE DONOSO CORTES, 80T, 28015, MADRID, MADRID, ESPAÑA",
          addressFormat: "12",
          addressType: "01",
          order: "3"
        },
        {
          address: "AQUI LA CALLE, AQUI EL NUMERO, AQUI EL CÓDIGO, AQUI LA CIUDAD, AQUI LA PROVINCIA, AQUI EL PAIS",
          addressFormat: "12",
          addressType: "02",
          order: "2"
        }
      ],
      document: "24185476X",
      phoneCesAssociated: [{
        number: "34-915-236677",
        order: "7",
        type: "S"
      }, {
        number: "34-912-276378",
        order: "79",
        type: "N"
      }],
      sessionStorageAddress: "AQUI LA CALLE, AQUI EL NUMERO, AQUI EL CÓDIGO, AQUI LA CIUDAD, AQUI LA PROVINCIA, AQUI EL PAIS",
      sessionStorageCes: false,
      sessionStoragePhone: ""
    }
    expect(component.checkSessionStorage(element)).toBeUndefined
  });

  it('checkSessionStorage 2', () => {
    const element = {
      beneficiary: "MARIO PMG WEBÑ",
      ces: true,
      deliveryAddress: [
        {
          address: "CALLE DONOSO CORTES, 80T, 28015, MADRID, MADRID, ESPAÑA",
          addressFormat: "12",
          addressType: "01",
          order: "3"
        },
        {
          address: "AQUI LA CALLE, AQUI EL NUMERO, AQUI EL CÓDIGO, AQUI LA CIUDAD, AQUI LA PROVINCIA, AQUI EL PAIS",
          addressFormat: "12",
          addressType: "02",
          order: "2"
        }
      ],
      document: "24185476X",
      phoneCesAssociated: [{
        number: "34-915-236677",
        order: "7",
        type: "S"
      }, {
        number: "34-912-276378",
        order: "79",
        type: "N"
      }],
      sessionStorageAddress: "",
      sessionStorageCes: true,
      sessionStoragePhone: "34-915-236677"
    }
    expect(component.checkSessionStorage(element)).toBeUndefined
  });
});
