// angular imports
import { Component, OnInit, OnChanges, Input, Output, EventEmitter, ViewChild } from '@angular/core';

// angular material imports
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';

@Component({
  selector: 'app-customization-table',
  templateUrl: './customization-table.component.html'
})

export class CustomizationTableComponent implements OnChanges {
  @Input() itemsPerPage!: string;
  @Input() representativeList!: any;
  @Input() selectedTypeHolderCommunicationsAdress!: string;
  @Output() selectedBeneficiariesData = new EventEmitter<any[]>();

  // Angular Material variables
  public displayedColumns: string[] = ['beneficiary', 'deliveryAddress', 'ces', 'phoneCesAssociated'];
  public dataSource!: MatTableDataSource<any>;
  public disableCombo: any[] = [{}];
  public dataTableChanged!: any[];
  public auxArray!: any[];
  public firstTime = true;

  // Table sort variable
  @ViewChild(MatSort, { static: true })
  sort!: MatSort;

  // Table paginator variable
  @ViewChild(MatPaginator, { static: true })
  paginator!: MatPaginator;

  /**
   * Initializes the table, the sort and paginator
   */
  ngOnChanges() {
    // The first time the info is loaded, save the beneficiary info the the global variable
    if (this.representativeList && this.firstTime) {
      // Firt time variable
      this.firstTime = false;
      // Clone of the beneficiary data table
      this.dataTableChanged = JSON.parse(JSON.stringify(this.representativeList));
      this.auxArray = JSON.parse(JSON.stringify(this.representativeList));
      // Set the preferred phone and address in the cloned list
      this.dataTableChanged.forEach((element) => {
        this.checkSessionStorage(element);
      });
      // Emit the list to the parent
      this.selectedBeneficiariesData.emit(this.dataTableChanged);
    }
    // Initialize mat-table
    this.dataSource = new MatTableDataSource(this.representativeList);
    // Clean all text in mat-paginator
    this.dataSource.sort = this.sort;
    this.paginator._intl.nextPageLabel = '';
    this.paginator._intl.previousPageLabel = '';
    this.paginator._intl.itemsPerPageLabel = '';
    this.paginator._intl.firstPageLabel = '';
    this.paginator._intl.lastPageLabel = '';
    // Initialize paginator
    this.dataSource.paginator = this.paginator;
    // Initialize the combo disabled object
    if (this.representativeList) {
      this.representativeList.forEach((element: any) => {
        this.disableCombo.push({ disable: false });
      })
    }
  }

  checkSessionStorage(element: any) {
    if (element.ces && !element.sessionStoragePhone) {
      element.phoneCesAssociated = element.phoneCesAssociated[0];
    } else if (element.ces && element.sessionStoragePhone) {
      element.phoneCesAssociated = element.phoneCesAssociated.find((data: any) => data.number === element.sessionStoragePhone)
    }
    if (element.sessionStorageCes) {
      element.ces = true;
    } else {
      element.ces = false;
    }
    if (element.sessionStorageAddress) {
      element.deliveryAddress = element.deliveryAddress.find((data: any) => data.address === element.sessionStorageAddress)
    } else {
      element.deliveryAddress = element.deliveryAddress[0];
    }
  }

  /**
   * Funcionality for disable or enable the ces phone combo if the ces checkbox is check or uncheck
   *
   * @param {*} event Event of the ces checkbox
   */
  enableDisablePhonesSelect(event: any) {
    // If the ces checkbox is check, enable the phone combo
    if (event.checked) {
      this.disableCombo[event.source.value].disable = false;
      this.representativeList[event.source.value].sessionStorageCes = true;
      // If the ces checkbox is not check, disable the phone combo
    } else {
      this.disableCombo[event.source.value].disable = true;
      this.representativeList[event.source.value].sessionStorageCes = false;
    }
  }

  /**
   * Update the variable with the data of the table when the input data changes
   *
   * @param {*} event Event of the input beneficiary name
   * @param {string} document Document of the beneficiary
   */
  changeBeneficiaryName(event: any, document: string) {
    // Set the name value in the representatives info variable and emit this variable to the parent
    this.dataTableChanged.find(element => element.document === document).beneficiary = event.target.value;
    this.selectedBeneficiariesData.emit(this.dataTableChanged);
  }

  /**
   * Update the variable with the data of the table when the address changes
   *
   * @param {*} event Event of the beneficiary address
   * @param {string} document Document of the beneficiary
   */
  changeDeliveryAddress(event: any, document: string) {
    // Set the address value in the representatives info variable and emit this variable to the parent
    this.auxArray.forEach((element: any) => {
      if (element.document === document) {
        this.dataTableChanged.find(element => element.document === document).deliveryAddress =
          element.deliveryAddress.find((element: any) => element.address = event.value);
      }
    });
    this.selectedBeneficiariesData.emit(this.dataTableChanged);
  }

  /**
   * Update the variable with the data of the table when ces checkbox changes
   *
   * @param {*} event Event of the ces checkbox
   * @param {string} document Document of the beneficiary
   */
  changeCes(event: any, document: string) {
    // If the checkbox is not checked, set the associated phone to an empty value
    if (!event.checked) {
      this.dataTableChanged.find(element => element.document === document).phoneCesAssociated = '';
    }
    // Set the ces value in the representatives info variable and emit this variable to the parent
    this.dataTableChanged.find(element => element.document === document).ces = event.checked;
    this.selectedBeneficiariesData.emit(this.dataTableChanged);
  }

  /**
   * Update the variable with the data of the table when the phone combo changes
   *
   * @param {*} event Event of the ces phone combo
   * @param {string} document Document of the beneficiary
   */
  changePhone(event: any, document: string) {
    this.dataTableChanged.find(element => element.document === document).phoneCesAssociated = event.value;
    // Set the phone value in the representatives info variable and emit this variable to the parent
    this.auxArray.forEach((element: any) => {
      if (element.phoneCesAssociated && element.document === document) {
        this.dataTableChanged.find(element => element.document === document).phoneCesAssociated =
          element.phoneCesAssociated.find((element: any) => element.number = event.value);
      }
    });
    this.selectedBeneficiariesData.emit(this.dataTableChanged);
  }
}
