// angular imports
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

// application services imports
import { TranslateService } from '@ngx-translate/core';
import { CustomizationService } from '../../shared/services/customization.service';
import { SessionStorageService } from '../../shared/services/session-storage.service';

// darwin services imports
import { LoggerService } from '@ng-darwin/logger'

// angular material imports
import { MatDialog } from '@angular/material';

// shared components imports
import { ModalComponent } from '../../shared/components/modal/modal.component';
import { LOGO_URL, CARD_IMAGE_SMALL } from '../../shared/constants/utils.constants';
import { ifStmt } from '@angular/compiler/src/output/output_ast';
import { ConfigService } from '@ng-darwin/config';

@Component({
  selector: 'app-customization',
  templateUrl: './customization.component.html',
  styleUrls: ['./customization.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CustomizationComponent implements OnInit {
  // Images variables
  public logoUrl = LOGO_URL;
  public cardImage = CARD_IMAGE_SMALL;

  // Manage the error variables
  public isError = false;
  public errorMessage!: string;
  public errorMessageSecondLine!: string;

  // sessionStorage variables
  public appObject!: any;
  public cardDescription!: string;
  public branchUser!: string;
  public branchCode!: string;
  public personId!: string;
  public personType!: string;
  public productId!: string;
  public subProductId!: string;
  public representatives!: any[];

  // application variables
  public customizationInfo!: any;
  public companyAddressInfo!: any[];
  public officeAddressInfo!: any[];
  public representativesInfo!: any[];
  public companyName = 'Nombre persona Jurídica';
  public selectedAddress!: string;
  public selectedTypeOfSentAddress!: string;
  public showCustomAddressField = false;
  public selectedTypeHolderCommunicationsAdress!: string;
  public representativeList!: any[];
  public selectedCompanyName!: string;
  public selectedDataFromTable!: any[];
  public shippingType!: string;
  public back!: string;
  public itemsPerPage: any;

  constructor(
    private readonly sessionStorageService: SessionStorageService,
    private readonly router: Router,
    private readonly translateService: TranslateService,
    private readonly customizationService: CustomizationService,
    private readonly loggerService: LoggerService,
    private readonly dialog: MatDialog,
    private readonly activatedRoute: ActivatedRoute,
    private readonly configService: ConfigService
  ) { }

  ngOnInit() {
    // If the sessionStorage appObject not exist, go to the first page
    if (!sessionStorage.getItem('appObject')) {
      this.router.navigate(['/cards']);
    }

    this.activatedRoute.queryParams.subscribe(params => {
      // Param if comes from other page
      this.back = params.back;
    });

    // Scroll to the top of the page
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });

    // get the sessionStorage info
    this.getInfoSessionStorage();

    // call to service and treatment of results
    this.getCustomizationInfo();

    // Set the items per page in the table component
    this.itemsPerPage = this.configService.config.app.itemsPerPage;
  }

  /**
   * Getting the sessionStorage service
   */
  getInfoSessionStorage() {
    this.appObject = this.sessionStorageService.getSessionStorage();
    if (this.appObject) {
      // Card selected data
      if (this.appObject.localContracts) {
        this.cardDescription = this.appObject.localContracts.productDesc;
        this.productId = this.appObject.localContracts.productId;
        this.subProductId = this.appObject.localContracts.subProductId;
      }
      // Branch data
      if (this.appObject.office) {
        this.branchUser = this.appObject.office.officeTeller;
        this.branchCode = this.appObject.office.officeId;
      }
      // Client data
      if (this.appObject.company) {
        this.personId = this.appObject.company.personId;
        this.personType = this.appObject.company.personType;
      }

      // Beneficiaries data
      this.representatives = this.appObject.representatives;
    }
  }

  /**
   * Update customer address field if the holder communications address is 01
   *
   * @param {*} event Address selected event
   */
  getSelectedAddress(event: any) {
    // Update the customer address and show the custom address field
    if (this.selectedTypeHolderCommunicationsAdress === '1') {
      this.showCustomAddressField = true;
      this.selectedTypeOfSentAddress = this.selectedAddress;
    }
  }

  /**
   * Show customer address field if the holder communications address is 02 or 03
   *
   * @param {*} event Selected Holder event
   */
  getSelectedHolderCommunicationsAdress(event: any) {
    // Get the event value
    this.selectedTypeHolderCommunicationsAdress = event.value;
    // If the CommunicationsAddress value is 02 or 03, the custom address field is shown with the right data
    if (this.selectedTypeHolderCommunicationsAdress === '1') {
      // Show the custom address field and set the right data to it
      this.showCustomAddressField = true;
      this.selectedTypeOfSentAddress = this.selectedAddress;
      // Update the representatives shipping address
      if (this.selectedDataFromTable) {
        this.selectedDataFromTable.forEach(element => {
          element.deliveryAddress = this.representativeList.find(data => data.document === element.document).deliveryAddress[0];
        })
      }
    } else if (this.selectedTypeHolderCommunicationsAdress === '3') {
      // Show the custom address field and set the right data to it
      this.showCustomAddressField = true;
      this.selectedTypeOfSentAddress = this.officeAddressInfo[0].address;
      // Update the representatives shipping address
      if (this.selectedDataFromTable) {
        this.selectedDataFromTable.forEach(element => {
          element.deliveryAddress = this.representativeList.find(data => data.document === element.document).deliveryAddress[0];;
        })
      }
    } else {
      // Hide the custom address field and set the right data to it
      this.showCustomAddressField = false;
    }
  }

  /**
   * Get the customization service info and set it to the variables
   */
  getCustomizationInfo() {
    this.customizationService.fetchCustomizationInfo(this.personId, this.personType).subscribe({
      next: (response: any) => {
        if (response.error && response.error.errorCode) {
          // If the service get an errorCode, the ErrorComponent is shown with the message
          this.isError = true;
          this.errorMessage = response.error.errorCode;
          this.errorMessageSecondLine = response.error.errorDesc;
        } else {
          // Get the response
          this.customizationInfo = response;
          // Get the company addresses info and order the company addresses by the order field
          this.companyAddressInfo = this.customizationInfo.companyAddresses;
          // asiganmos la primera direccion de la lista que devuelve la funcion de ordenacion
          // con el criterio de addressType y order informado
          // si no se cumple ese criterio devuelve la primera de la lista
          this.companyAddressInfo = this.getTypeOneOrFirst(this.companyAddressInfo, 'addressType');
          // Get the office addresses info and order the office addresses info
          this.officeAddressInfo = this.customizationInfo.officeAddresses;
          // asiganmos la primera direccion de la lista que devuelve la funcion de ordenacion
          // con el criterio de addressType y order informado
          // si no se cumple ese criterio devuelve la primera de la lista
          this.officeAddressInfo = this.getTypeOneOrFirst(this.officeAddressInfo, 'addressType');
          // Get the representatives info
          this.representativesInfo = this.customizationInfo.representatives;
          // Get the Selected Address
          this.checkUsualAndShippingAddress();
          // If exists shipping type in the sessionStorage, bind the value
          if (this.appObject.shippingType) {
            this.shippingType = this.appObject.shippingType;
            this.getSelectedHolderCommunicationsAdress({ value: this.shippingType });
          }

          // Get the company name and set the value in the sessionStorage if existe
          if (this.appObject.company.companyNameCard) {
            this.companyName = this.appObject.company.companyNameCard;
            this.changeCompanyName({ target: { value: this.companyName } });
          } else {
            this.companyName = this.customizationService.formatForthStampingLine(this.customizationInfo.companyName);
            this.changeCompanyName({ target: { value: this.companyName } });
          }
          // Get the representatives info
          this.representativeList = this.getRepresentativesTableInfo(this.representativesInfo);
        }
      },
      error: (error: any) => {
        // If the services get an http error, the ErrorComponent is shown with the error description
        this.isError = true;
        this.errorMessage = 'customizationServiceError';
        // The error is logged in Kibana
        this.loggerService.logError({
          log: error,
          component: 'CustomizationComponent'
        });
      }
    });
  }

  checkUsualAndShippingAddress() {
    // Actualizamos la dirección de envío según selección de tipo
    if (this.appObject.company.companyShippingAddress.address) {
      this.selectedAddress = this.appObject.company.companyShippingAddress.address;
    } else {
      this.selectedAddress = this.companyAddressInfo[0].address;
    }
    if (this.appObject.company.companyUsualAddress.address) {
      this.selectedAddress = this.appObject.company.companyUsualAddress.address;
    } else {
      this.selectedAddress = this.companyAddressInfo[0].address;
    }
  }

  /**
   * Get the element with param equal to 1, and if not exist, the first element.
   *
   * @param {*} list List of elements
   * @param {string} param Param to compare to 1
   * @returns Sorted list
   */
  getTypeOneOrFirst(list: any, param: string) {
    // Ordenamos las direcciones segun criterio param
    // aseguramos que la elegida tenga informada el campo order
    // si no hay ninguna opcion que cumpla los criterios anteriores
    // devuelve la primera opcion de la lista
    if (list.find((element: any) => (element[param] === '01' && element.order !== '') )) {
      list.sort((a: any, b: any) => {
        if (a[param] === b[param]) {
          return 0;
        }
        else if (a[param] === null) {
          return 1;
        }
        else if (b[param] === null) {
          return -1;
        }
        return a[param] < b[param] ? -1 : 1;
      });
    }
    return list;
  }

  /**
   * Get the representatives table info
   */
  getRepresentativesTableInfo(representatives: any[]) {
    const representativeList: any[] = [];
    // Match the beneficiaries info in the session storage with the beneficiaries info from the service.
    representatives.forEach(element => {
      // Get only the representatives selected in the previous page
      const representativeObject: any = this.representatives.filter(representative => representative.personId === element.personId);
      // Get the sorted addresses of each representative
      // asiganmos la primera direccion de la lista que devuelve la funcion de ordenacion
      // con el criterio de addressType y order informado
      // si no se cumple ese criterio devuelve la primera de la lista
      const representativeAdressess: any = this.getTypeOneOrFirst(element.addresses, 'addressType');

      // Set the information passed to the TableComponent
      if (representativeObject.length > 0) {
        // Push in the array the representative table data
        representativeList.push({
          beneficiary:
            this.appObject.representatives.find((representative: any) => representative.personId === element.personId).personNameCard
              ? this.appObject.representatives.find((representative: any) => representative.personId === element.personId).personNameCard
              : this.customizationService.formatBeneficiaryName(representativeObject[0].name),
          document: representativeObject[0].document,
          deliveryAddress: representativeAdressess,
          ces: element.phones.length > 0,
          phoneCesAssociated: element.phones.length > 0 ? element.phones : '',
          mails: representativeObject[0].emails,
          // The address set in the sessionStorage for the representative
          sessionStorageAddress: this.handleStorageAddress(element),
          // The phone set in the sessionStorage for the representative
          sessionStoragePhone: this.handleStoragePhone(element),
          // The ces selector in the sessionStorage for the representative
          sessionStorageCes: this.handleStorageCes(element)
        });
      }
    });
    return representativeList;
  }

  // The address set in the sessionStorage for the representative
  handleStorageAddress(element: any) {
    return this.appObject.representatives.find(
      (representative: any) => representative.personId === element.personId
    ).shippingAddress
      ? this.appObject.representatives.find(
        (representative: any) => representative.personId === element.personId
      ).shippingAddress.address
      : ''
  }

  // The phone set in the sessionStorage for the representative
  handleStoragePhone(element: any) {
    return this.appObject.representatives.find(
      (representative: any) => representative.personId === element.personId
    ).cesPhone
      ? this.appObject.representatives.find(
        (representative: any) => representative.personId === element.personId
      ).cesPhone.number
      : ''
  }

  // The ces selector in the sessionStorage for the representative
  handleStorageCes(element: any) {
    return this.appObject.representatives.find(
      (representative: any) => representative.personId === element.personId
    ).ces === undefined
      ? element.phones.length > 0
      : this.appObject.representatives.find(
        (representative: any) => representative.personId === element.personId
      ).ces
  }

  /**
   * Save the company name
   */
  changeCompanyName(event: any) {
    this.selectedCompanyName = event.target.value;
  }

   /**
   * Validate the fields of the page
   */
  validateFields() {
   // antes de proceder a dar de alta en los sistemas toda la documentación del nuevo contrato
   // validamos aquellos campos que MMPP necesita como obligatorios y asi evitar el error en el 
   // último paso donde el usuario nada puede hacer 
   // los campos principales para controlar son el valor order de las direcciones 
	 
    let isErrorNameCard = false;
	 //Validamos el nombre de estampacion de todos los beneficiarios
	 this.selectedDataFromTable.forEach((element: any) => {
		if (element.beneficiary === ' ' || !element.beneficiary) {
			//marcamos error por nombre estampacion de apoderado no informad0
			isErrorNameCard = true;
		}
	 });
	 
    //Iniciamos validaciones de pantalla antes de enviar para informar al usuario
    if (this.selectedCompanyName === ' ' || !this.selectedCompanyName) {
      //Validamos el nombre de estamapcion de la empresa
      this.openModal('companeNameMandatoryField');
    } else if (!this.selectedAddress) {
      //Validamos el dirección de entrega informada
      this.openModal('selectedAddressMandatoryField');
	  } else if (!this.selectedTypeHolderCommunicationsAdress) {
      //Validamos el tipo de envio elegido
      this.openModal('holderCommunicationMandatoryField');
    } else if (isErrorNameCard){
      //Validamos el nombre de estamapcion de los apoderados
	    this.openModal('holderNameCardMandatoryField');
	  } else {
      //Si todo OK actualizamos la sesión con la informacion para poder enviar
      this.setSessionStorageInfo();
      
      // una vez actualizada la session terminamos las comprobaciones de datos
      // en lo relativo a las direcciones de entrega ya que siempre hay que 
      //asegurar que tenemos una con el valor de order informado
      if (this.postValidationAddressCompany()) {
        // si la dirección elegida (usual es igual a shipping) de la empresa no tiene order 
        // sacamos mensaje al usuario con el mensaje correspondiente
		    this.openModal('companyAddressMandatoryField');
	    } else if (this.postValidationAddressHolders()){
        // Si la dirección de alguno de los apoderados no tiene order en la shipping y en la usual
        //sacamos mensaje al usuario con el mensaje correspondiente
		    this.openModal('holdersAddressMandatoryField');
	    } else { 
      // Si todo ha ido bien  enviamos a la siguiente pantalla
      // con estas validaciones aseguramos que los datos de direcciones siempre van informados
      // y evitamos que la contratacion se rechace por este motivo  
		  this.router.navigate(['/sign']);
	    }
	   } 
  }


  /**
   * Open the modal window
   *
   * @param {string} bodyText Paremeter with the text of the modal body
   */
  openModal(bodyText: string) {
    this.dialog.open(ModalComponent, {
      data: {
        title: 'warning',
        bodyText
      }
    });
  }

  /**
   * Get the data from beneficiaries table
   *
   * @param {any[]} event List with all the beneficiary data
   */
  getSelectedBeneficiaries(event: any[]) {
    this.selectedDataFromTable = event;
  }

  /**
   * Validation in the sesionStorage for the addressInfo from the page before go to the next page
   *
   * @returns true/false
   */
   postValidationAddressCompany(){
	  
	 //validamos existencia de dirección de empresa con indicador order informado
   // si el order de la direccion seleccionada esta vacia 
   //  entonces es un error   
	 if (this.appObject.company.companyUsualAddress.order === '' || !this.appObject.company.companyUsualAddress.order) {
     // si no tiene order salimos indicando error
      return true;
	 }
  
    return false;
   }	
  
   /**
   * Validation in the sesionStorage for the addressInfo from the page before go to the next page
   *
   * @returns true/false
   */ 
   postValidationAddressHolders() {
   //manejamos variable ya que tenemos una lista que validar
	 let isErrorPostValidationAddressHolders = false;
 	 //validamos existencia de dirección de holders con indicador order informado 
	 this.appObject.representatives.forEach((element: any) => {
		// Para cada apoderado comprobamos la existencia de order
    // bien la usual bien en la shipping 
	 if ((element.usualAddress.order === '' || !element.usualAddress.order) 
        && (element.shippingAddress.order === '' || !element.shippingAddress.order)) {
			//si ninguna de las dos posibles direcciones tiene informado order
      // salimos por error
      // si el order de la direccion seleccionada y el order de la usual esta vacia 
      //  entonces es un error
			isErrorPostValidationAddressHolders = true;
		}
	  });	
    return isErrorPostValidationAddressHolders;
   }	

  /**
   * Set in the sesionStorage all the info from the page before go to the next page
   *
   */
  setSessionStorageInfo() {
    // Set the shipping type
    this.appObject.shippingType = this.selectedTypeHolderCommunicationsAdress;
    // Set the company document
    this.appObject.company.companyDocument = this.customizationInfo.companyDocument;
    // Set the type of the company document
    this.appObject.company.typeCompanyDocument = this.customizationInfo.typeCompanyDocument;
    // Set the company name
    this.appObject.company.companyName = this.customizationInfo.companyName;
    // Set the company name in the card
    if (this.selectedCompanyName) {
      this.appObject.company.companyNameCard = this.selectedCompanyName.trim();
    } else {
      this.appObject.company.companyNameCard = this.customizationInfo.companyName;
    }
    // Set the company usual address
    this.appObject.company.companyUsualAddress = this.companyAddressInfo.find(element => element.address === this.selectedAddress);
    if (this.selectedTypeHolderCommunicationsAdress === '1') {
      // Set the company shipping address
      this.appObject.company.companyShippingAddress = this.companyAddressInfo.find(element => element.address === this.selectedAddress);
    } else {
      // Set the company shipping address as an empty object           
      this.appObject.company.companyShippingAddress = { address: '', addressType: '', addressFormat: '', order: '' };
    }
    // Set the company emails
    this.appObject.company.companyEmails = this.customizationInfo.companyEmails !== null ? this.customizationInfo.companyEmails : [];
    // Set the company phones
    this.appObject.company.companyPhones = this.customizationInfo.companyPhones !== null ? this.customizationInfo.companyPhones : [];
    // Set the office name
    this.appObject.office.officeName = this.customizationInfo.officeName;
    // Set the office location
    this.appObject.office.officeLocation = this.customizationInfo.officeLocation;
    // Set the office address
    this.appObject.office.officeAddress = this.getTypeOneOrFirst(this.customizationInfo.officeAddresses, 'addressType')[0];
    // Set all the info about all representatives
    this.appObject.representatives.forEach((element: any) => {
      // Set the name in the card
      this.setUserInfo(element);
    });
    // Save the variables in sessionStorage
    this.sessionStorageService.setSessionStorage(this.appObject);
  }

  /**
   * Sets User´s info.
   *
   */
  setUserInfo(element: any) {
    // Add nombre estampacion apoderados
    element.personNameCard = this.selectedDataFromTable.find(data => data.document === element.document).beneficiary.trim();
    // Add sex to representatives
    element.sex = this.customizationInfo.representatives.find((data: any) => data.personId === element.personId).sex;
    // Set the shipping address
    element.shippingAddress = this.selectedDataFromTable.find(data => data.document === element.document).deliveryAddress;
    // If the shippingAddress is empty, is saved an empty object
    if (this.selectedTypeHolderCommunicationsAdress === '1') {
      element.shippingAddress = { address: '', addressType: '', addressFormat: '', order: '' };
    } else {
        // Si hay shippingAdrres se recuperan los datos asociados a ella
        this.setShippingAddressHolderInfo(element);
    }
    // Set the usual address
    element.usualAddress = this.getTypeOneOrFirst(this.customizationInfo.representatives
      .find((data: any) => data.personId === element.personId).addresses,'addressType')[0];
    // If the usualAddress is empty, is saved an empty object
    if (element.usualAddress === '' || !element.usualAddress) {
      element.usualAddress = { address: '', addressType: '', addressFormat: '', order: '' };
    }
    // Set the cesp phone
    element.cesPhone = this.selectedDataFromTable.find(data => data.document === element.document).phoneCesAssociated;
    // If the cesPhone is empty, is saved an empty object
    if (element.cesPhone === '' || !element.cesPhone) {
      element.cesPhone = { number: '', type: '', order: '' };
    }
    // Set the preferred phone
    element.preferredPhone = this.representativeList.find(data => data.document === element.document).phoneCesAssociated[0];
    // If the preferredPhone is empty, is saved an empty object
    if (element.preferredPhone === '' || !element.preferredPhone) {
      element.preferredPhone = { number: '', type: '', order: '' };
    }
    // Set if the user has ces
    element.ces = this.selectedDataFromTable.find(data => data.document === element.document).ces;
    // Set the preferred email
    element.preferredEmail = this.representativeList.find(data => data.document === element.document).emails;
    // If the preferredEmail is empty, is saved an empty object
    if (element.preferredEmail === '' || !element.preferredEmail) {
      element.preferredEmail = { email: '', type: '' };
    }
  }  
 

 /**
   * Sets ShippingAddressUser´s info.
   *
   */
  setShippingAddressHolderInfo(element: any) {
    
    // Si tenemos shippingAddress entonces hay que buscar sus datos internos para lo cual rescorremos los apoderados
    this.customizationInfo.representatives.forEach((apoderado: any) => {
      // si coindiden los apoderados buscamos en sus objetos direcciones  
		  if (element.personId === apoderado.personId) { 
          // iniciamos el recorrido de las direcciones del apoderado
			    apoderado.addresses.forEach((direccion: any) => {
            // si alguna address coincide entonces es la correcta
				    if (direccion.address === element.shippingAddress.address){
              // asignamos el objeto direccion a la shippingAddress
				      element.shippingAddress = direccion;
				    }
			    });
		    }	
	    }); 
    } 

  /**
   * Refresh the current component
   */
  reloadComponent() {
    // Clean the sessionStorage
    this.cleanSessionStorage();
    // Reload the component
    this.router.navigateByUrl('/RefreshComponent', { skipLocationChange: true }).then(() => {
      this.router.navigate(['/customization']);
    });
  }

  // Clean the sessionStorage info
  cleanSessionStorage() {
    // Clean all the sessionStorage variables
    this.appObject.shippingType = '';
    this.appObject.company.companyDocument = '';
    this.appObject.company.typeCompanyDocument = '';
    this.appObject.company.companyName = '';
    this.appObject.company.companyNameCard = '';
    this.appObject.company.companyUsualAddress = '';
    this.appObject.company.companyShippingAddress = '';
    // Clean all the representatives info
    this.appObject.representatives.forEach((element: any) => {
      element.personNameCard = '';
      element.shippingAddress = '';
      element.usualAddress = '';
      element.cesPhone = '';
      element.preferredPhone = '';
      element.ces;
      element.preferredEmail = '';
    });
    // Save the variables in sessionStorage
    this.sessionStorageService.setSessionStorage(this.appObject);
  }

  /**
   * Go to the previous page
   */
  goBack() {
    this.router.navigate(['/beneficiaries'], {
      queryParams: {
        back: 'y'
      }
    });
  }
}
