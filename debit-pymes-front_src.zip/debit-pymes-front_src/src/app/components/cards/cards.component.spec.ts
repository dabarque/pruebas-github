import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Router, ActivatedRoute } from '@angular/router';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ConfigTestingModule } from '@ng-darwin/config';
import { LoggerTestingModule } from '@ng-darwin/logger';
import { SecurityTestingModule } from '@ng-darwin/security';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { CardsComponent } from './cards.component';
import { CardComponent } from './components/card/card.component';
import { ErrorComponent } from 'src/app/shared/components/error/error.component';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';
import { HeaderComponent } from 'src/app/shared/components/header/header.component';
import { TranslateModule } from '@ngx-translate/core';
import { AngularMaterialModule } from 'src/app/shared/angular-material.module';
import { CarouselService } from 'src/app/shared/services/carousel.service';
import { Observable } from 'rxjs';


describe('CardsComponent', () => {
  let component: CardsComponent;
  let fixture: ComponentFixture<CardsComponent>;

  class ActivatedRouteMock {
    queryParams = new Observable(observer => {
      const urlParams = {
        branchCode: '0149',
        branchUser: 'xe18738',
        personId: '12929292',
        personType: 'J',
        back: 'n'
      }
      observer.next(urlParams);
      observer.complete();
    });
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CardsComponent, CardComponent, ErrorComponent, ModalComponent, HeaderComponent ],
      imports: [
        BrowserAnimationsModule,
        TranslateModule.forRoot(),
        AngularMaterialModule,
        HttpClientTestingModule,
        ConfigTestingModule.forRoot({
          appKey: 'appKey_mock',
          appName: 'appName_mock',
          app: {
            docRoutes: {
              dw: 'dw_url_mock',
              jsonServer: 'jsonServer_url_mock',
              ng: 'ng_url_mock',
              ngCli: 'ngCli_url_mock'
            },
            itemsPerPage: '5',
            rest: {
              host: 'localhost',
              port: 3000,
              ssl: false,
              basePath: 'api/v1',
              endpoints: {
                carousel: {
                  host: 'localhost',
                  port: 3000,
                  ssl: false,
                  method: 'GET',
                  uri: 'persons/:personType/:personId/carousel'
                },
                beneficiaries: {
                  host: 'localhost',
                  port: 3000,
                  ssl: false,
                  method: 'GET',
                  uri: 'persons/:personType/:personId/beneficiaries',
                  queryParams: [
                    'productId',
                    'subProductId'
                  ]
                },
                customization: {
                  host: 'localhost',
                  port: 3000,
                  ssl: false,
                  method: 'POST',
                  uri: 'persons/customization'
                }
              }
            }
          }
        }),
        SecurityTestingModule,
        LoggerTestingModule
      ],
      providers: [
        CarouselService,
        { provide: Router, useClass: class { navigate = jasmine.createSpy("navigate"); } },
        { provide: ActivatedRoute, useClass: ActivatedRouteMock }
      ]
    })
    .compileComponents();
  }));


  beforeEach(() => {
    fixture = TestBed.createComponent(CardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('setSessionStorageInfo', () => {
    component.back = 'y';
    expect(component.setSessionStorageInfo()).toBeUndefined();
  })
});
