import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';

import { CardComponent } from './card.component';
import { TranslateModule } from '@ngx-translate/core';
import { AngularMaterialModule } from 'src/app/shared/angular-material.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';

@NgModule({
  imports: [],
  declarations: [],
  entryComponents: [ModalComponent]
})
export class FakeTestDialogModule {}


describe('CardComponent', () => {
  let component: CardComponent;
  let fixture: ComponentFixture<CardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CardComponent, ModalComponent ],
      imports: [ 
        FakeTestDialogModule,
        BrowserAnimationsModule,
        TranslateModule.forRoot(),
        AngularMaterialModule
      ],
      providers: [
        { provide: Router, useClass: class { navigate = jasmine.createSpy("navigate"); } }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should isOtherCard false', () => {
    component.productId='';
    component.subProductId='';
    component.appObject.localContracts = {
      productId: '',
      subProductId: '',
      localContract: {
        productId: ''
      },
      partenonContracts: {
        subProductId: ''
      }
    }
    expect(component.isOtherCard()).toBeFalse();
  });

  it('should isOtherCard true', () => {
    component.productId='Prueba';
    component.subProductId='Prueba';
    component.appObject.localContracts = {
      productId: 'Prueba 2',
      subProductId: 'Prueba 2',
      localContract: {
        productId: ''
      },
      partenonContracts: {
        subProductId: ''
      }
    }
    expect(component.isOtherCard()).toBeTrue();
  });

  it('should saveCardValues true', () => {
    component.productId='Prueba';
    component.subProductId='Prueba';
    component.appObject.localContracts = {
      productId: 'Prueba 2',
      subProductId: 'Prueba 2',
      localContract: {
        contractId: ''
      },
      partenonContracts: {
        contractId: ''
      }
    }
    expect(component.saveCardValues()).toBeUndefined();
  });

  it('should saveCardValues false', () => {
    component.productId='';
    component.subProductId='';
    component.appObject.localContracts = {
      productId: 'Prueba 2',
      subProductId: 'Prueba 2',
      localContract: {
        productId: ''
      },
      partenonContracts: {
        subProductId: ''
      }
    }
    expect(component.saveCardValues()).toBeUndefined();
  });

  it('should selectCard false', () => {
    component.productId='';
    component.subProductId='';
    component.appObject.localContracts = {
      productId: '',
      subProductId: '',
      localContract: {
        productId: ''
      },
      partenonContracts: {
        subProductId: ''
      }
    }
    expect(component.selectCard()).toBeUndefined();
  });

  it('should selectCard true', () => {
    component.productId='Prueba';
    component.subProductId='Prueba';
    component.appObject.localContracts = {
      productId: 'Prueba 2',
      subProductId: 'Prueba 2',
      localContract: {
        productId: ''
      },
      partenonContracts: {
        subProductId: ''
      }
    }
    expect(component.selectCard()).toBeUndefined();
  });

});
