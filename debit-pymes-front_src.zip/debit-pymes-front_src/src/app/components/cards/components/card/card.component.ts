// angular imports
import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';

// angular material imports
import { MatDialog } from '@angular/material';

// modal component imports
import { ModalComponent } from '../../../../shared/components/modal/modal.component';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnInit {
  @Input() cardImageUrl!: string;
  @Input() cardName!: string;
  @Input() productId!: string;
  @Input() subProductId!: string;
  @Input() standarRef!: string;
  @Input() economicCondition!: string;
  @Input() typeCard!: string;
  @Input() brandCard!: string;
  @Input() estampacionCode!: string;

  // Sessionstorage object
  public appObject = JSON.parse(sessionStorage.getItem('appObject') || '{}');

  // Beneficiaries page route
  public beneficiaryRoute = '/beneficiaries';

  constructor(private readonly router: Router, private readonly dialog: MatDialog) { }

  ngOnInit() { }

  /**
   * Open the modal with the card changes info or redirect to the beneficiaries page
   */
  selectCard(){
    if(this.isOtherCard()){
      // Open the modal window
      this.openModal();
    } else {
      // Save the card values in the sessionStorage
      this.saveCardValues();
      // Navigate to the next page
      this.router.navigate([this.beneficiaryRoute]);
    }
  }

  /**
   * Open the modal and capture the continue button click event
   */
  openModal() {
    // Open the modal whit custom body text, button option and route
    const dialogRef = this.dialog.open(ModalComponent, {
      data: {
        title: 'warning',
        bodyText: 'anotherCardSelection',
        buttons: true,
        route: this.beneficiaryRoute
      }
    });
    // Close the modal when click continue button
    dialogRef.afterClosed().subscribe(result => {
      if(result){
        // Save cards values
        this.saveCardValues();
        // Go to beneficiaries page
        this.router.navigate([this.beneficiaryRoute]);
      }
    });
  }

  /**
   * Calculate if the user has chosen a different card than the initial one
   */
  isOtherCard(): boolean{
    // Check if the selection is a different card
    if (
      this.appObject.localContracts.productId &&
      (this.productId !== this.appObject.localContracts.productId ||
      this.appObject.localContracts.subProductId !== this.subProductId)
    ) {
      return true;
    } else {
      return false;
    }
  }

  /**
   * Saves in the SessionStorage the info of the card selected
   */
  saveCardValues(): void{
    // If the selection is a different card
    if (this.isOtherCard()) {
      // Clean all the cards values in sessionStorage
      if(this.appObject.localContracts.localContract){
        this.appObject.localContracts.localContract.contractId = '';
      }
      if(this.appObject.localContracts.partenonContract){
        this.appObject.localContracts.partenonContract.companyId = '';
        this.appObject.localContracts.partenonContract.branchId = '';
        this.appObject.localContracts.partenonContract.productId = '';
        this.appObject.localContracts.partenonContract.contractId = '';
      }
      this.appObject.localContracts.descriptionContract = '';
    }
    // Set the new card selected values in sessionStorage
    if(this.appObject.localContracts) {
      this.appObject.localContracts.productId = this.productId;
      this.appObject.localContracts.subProductId = this.subProductId;
      this.appObject.localContracts.productDesc = this.cardName;
      this.appObject.localContracts.standarRef = this.standarRef;
      this.appObject.localContracts.economicCondition = this.economicCondition;
      this.appObject.localContracts.typeCard = this.typeCard;
      this.appObject.localContracts.brandCard = this.brandCard;
      this.appObject.localContracts.estampacionCode = this.estampacionCode;
    }
    // Save object in sessionStorage
    sessionStorage.setItem('appObject', JSON.stringify(this.appObject));
  }
}
