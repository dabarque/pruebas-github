// angular imports
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

// application services imports
import { CarouselService } from '../../shared/services/carousel.service';
import { SessionStorageService } from '../../shared/services/session-storage.service';

// darwin arquitechture imports
import { LoggerService } from '@ng-darwin/logger';

// constants imports
import { APP_OBJECT } from '../../shared/constants/app-object.constants';
import { LOGO_URL, CARD_IMAGE } from '../../shared/constants/utils.constants';

@Component({
  selector: 'app-cards',
  templateUrl: './cards.component.html',
  styleUrls: ['./cards.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CardsComponent implements OnInit {
  // Images variables
  public logoUrl = LOGO_URL;
  public cardImage = CARD_IMAGE;

  // Query Params variables
  public personId!: string;
  public personType!: string;
  public back!: string;
  public userName: any;

  // Manage the error variables
  public isError = false;
  public errorMessage!: string;
  public errorMessageSecondLine!: string;

  // Carousel info
  public carouselInfo!: any;
  public productsList!: any;

  // Sessionstorage object
  public appSaveObject!: any;

  constructor(
    private readonly activatedRoute: ActivatedRoute,
    private readonly carouselService: CarouselService,
    private readonly sessionStorageService: SessionStorageService,
    private readonly loggerService: LoggerService
  ) { }

  ngOnInit() {
    // Get the query params from the url
    this.activatedRoute.queryParams.subscribe(params => {
      // Client info
      this.personId = params.personId;
      this.personType = params.personType;
      // Param if comes from other page
      this.back = params.back;
    });

    if (this.back) {
      // Scroll to the top of the page
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    }

    // Check if we have all the query params. If not we throw the error component
    if (!this.personId || !this.personType) {
      this.isError = true;
      this.errorMessage = 'queryParamsError';
    }

    // Setting the sessionStorageInfo
    this.setSessionStorageInfo();

    // Getting the carousel info
    this.getCarouselInfo();
  }

  /**
   * Set all the queryparams in the sessionStorage. This params are the branch code, the branch user,
   * the id of the client and the type of cliente
   */
  setSessionStorageInfo() {
    // If it comes from another page, we retrieve variables from sessionStorage
    if (this.back && this.back === 'y') {
      // Get the sessionStorage object
      this.appSaveObject = this.sessionStorageService.getSessionStorage();
      this.appSaveObject.company.personId = this.personId;
      this.appSaveObject.company.personType = this.personType;
      // Save the sessionStorage object
      this.sessionStorageService.setSessionStorage(this.appSaveObject);
    } else {
      // If it does not come from another page, we save the variables in sessionStorage
      APP_OBJECT.company.personId = this.personId;
      APP_OBJECT.company.personType = this.personType;
      // Save the sessionStorage object
      this.sessionStorageService.setSessionStorage(APP_OBJECT);
    }
  }

  /**
   * Get the cards info from the carousel service
   */
  getCarouselInfo() {
    // Call to the carousel service
    this.carouselService.fetchCarousel(this.personId, this.personType).subscribe({
      next: (response: any) => {
        this.carouselInfo = response;
        // If error code is in response, the ErrorComponent is shown with the error description
        if (this.carouselInfo.error && this.carouselInfo.error.errorCode) {
          this.isError = true;
          this.errorMessage = this.carouselInfo.error.errorCode;
          this.errorMessageSecondLine = this.carouselInfo.error.errorDesc;
        } else {
          // If no error code is in response, the carousel info is saved
          this.userName = this.carouselInfo.officeTeller;
          this.productsList = this.carouselInfo.products;
          this.appSaveObject = this.sessionStorageService.getSessionStorage();
          this.appSaveObject.office.officeId = this.carouselInfo.officeId;
          this.appSaveObject.office.officeTeller = this.carouselInfo.officeTeller;
          this.sessionStorageService.setSessionStorage(this.appSaveObject);
        }
      },
      error: (error: any) => {
        // If the call returns a http error code, the ErrorComponent is shown and the error is logged in kibana
        this.isError = true;
        this.errorMessage = 'carouselServiceError';
        // Error logged in kibana
        this.loggerService.logError({
          log: error,
          component: 'CardsComponent'
        });
      }
    });
  }
}
