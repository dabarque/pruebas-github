import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit, NgZone } from '@angular/core';
import { ConfigService } from '@ng-darwin/config';
import { SecurityService, HttpBareClient } from '@ng-darwin/security';
import { LoggerService } from '@ng-darwin/logger';
import { Subscription, interval, merge, fromEvent } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {
  title = 'Contratación tarjeta de débito Pymes';
  countDown = 0;
  docRoutes: { dw: string, jsonServer: string; ng: string; ngCli: string; };
  response: any;

  /**
   * Several services are injected into the constructor for the examples
   * The only mandatory service is securityService if you want the token to be managed by Darwin
   */
  constructor(
    private readonly configService: ConfigService,
    public securityService: SecurityService,
    private readonly loggerService: LoggerService,
    private readonly httpClient: HttpClient,
    private readonly httpBareClient: HttpBareClient,
    private readonly ngZone: NgZone,
    private readonly translate: TranslateService,
    private readonly activatedRoute: ActivatedRoute
  ) {
    // reference to documentation routes
    this.docRoutes = this.configService.config.app.docRoutes as any;
    this.activatedRoute.queryParams.subscribe(params => {
      this.translate.setDefaultLang('es');
      if (params.lang) {
        this.translate.use(params.lang);
      }
    });
  }

  async ngOnInit() {
    // Subscription to error and log events of modules
    // It can be deleted if you are not interested in
    this._subcribeToErrorEvents();
    this._subcribeToLogEvents();


    // THIS TWO LINES OF CODE ARE MANDATORY to manage the session and token:
    // - Subscription to session events (aboutToTimeout, timeout, resumed)
    // - Initialization of security service to manage the session and token
    this._subcribeToSessionEvents();

    await this.securityService.initialize();

    //  VERY IMPORTANT!!!
    //  PUT YOUR CODE HERE, AFTER SECURITY INITIALIZE PROMISE HAS BEEN FULLFILLED
    // **************************************************************************


    // this code and private methods are only used for the archetype to work, you can delete them
    this.countDown = Math.round(this.securityService.ttl / 1000);
    this._manageSession();
    this._logMessages();
  }

  /**
   * Method for a button click event inside the view
   */
  getRequestThroughHttpClient() {
    // Important! Note this request through httpClient always have auth & common headers if Security module has been loaded
    this.httpClient.get('http://localhost:3000/api/logger/logs').subscribe(value => {
      console.log('saved logs from db.json:', value);
      this.response = value;
    });
  }

  /**
   * Method for a button click event inside the view
   */
  getRequestThroughHttpBareClient() {
    // Important: Note that this request through httpBareClientService has no interceptors. It's a bare request
    this.httpBareClient.get('/api/alive', { responseType: 'text' }).subscribe(value => {
      console.log('alive response:', value);
      this.response = value;
    });
  }

  /**
   * Method for a button click event inside the view
   */
  postRequestThroughLoggerService() {
    // Important: Note this request always have common headers if Security module has been loaded,
    // but only have auth header if 'logger.isSecure' property is true
    this.loggerService.logError({
      log: 'my message to be logged',
      component: 'mycomponent'
    }).then(() => { this.response = 'Log enviado a fake Data Base. Se ha creado un nuevo registro en el fichero db.json'; });
  }

  /**
   * Method for close session and clean credentials
   */
  closeSession() {
    this.securityService.killSession();
    this.response = 'La sessión ha sido cerrada y las credenciales se han eliminado correctamente';
  }

  private _subcribeToErrorEvents() {
    const prefixConsoleError = (prefix: string) => ({ payload, event }: any) => console.log(prefix, payload, event);

    // listening error events of modules
    this.loggerService.onError$.subscribe(prefixConsoleError('Error event from Logger module.'));
    this.securityService.onError$.subscribe(prefixConsoleError('Error event from Security module.'));

  }

  private _subcribeToLogEvents() {
    const prefixConsoleLog = (prefix: string) => ({ payload, event }: any) => console.log(prefix, payload, event);

    // listening log events of modules
    this.loggerService.onLog$.subscribe(prefixConsoleLog('Log event from Logger module.'));
    this.securityService.onLog$.subscribe(prefixConsoleLog('Log event from Security module.'));
  }

  private _subcribeToSessionEvents() {
    const colorConsoleLog = (color: string) => ({ event }: any) => console.log(`%c${event}`, color);

    // listening security events
    this.securityService.onSessionAboutToTimeout$.subscribe(colorConsoleLog('background: khaki'));
    this.securityService.onSessionTimeout$.subscribe(() => {
      colorConsoleLog('background: tomato');
      if(this.configService.config.app.logoutUrl) {
        window.location.href = this.configService.config.app.logoutUrl.toString();
      }
    });
    this.securityService.onSessionResume$.subscribe(colorConsoleLog('background: lightgreen'));
    this.securityService.onSessionKilled$.subscribe(() => {
      colorConsoleLog('background: tomato');
      if(this.configService.config.app.logoutUrl) {
        window.location.href = this.configService.config.app.logoutUrl.toString();
      }
    });
  }

  /**
   * Manages the countdown
   * You can skip this method if you are not interested in how the countdown is developed
   */
  private _manageSession() {
    let moveOrTypeSubs: Subscription;
    let afterMouseMoveOrTypeSubs: Subscription;
    let intervalSubs: Subscription;

    const countDownFn = () => {
      if (this.countDown === 0) {
        intervalSubs.unsubscribe();
        afterMouseMoveOrTypeSubs.unsubscribe();
        moveOrTypeSubs.unsubscribe();
      } else {
        this.countDown -= 1;
      }
    };

    // it emits every second
    const interval$ = interval(1000);
    const subscribeToInterval = () => {
      // runOutsideAngular needed for Protractor e2e testing
      // https://medium.com/@jarifibrahim/the-curious-case-of-protractor-and-page-synchronization-58b4e81366ac
      this.ngZone.runOutsideAngular(() => {
        intervalSubs = interval$.subscribe(() => this.ngZone.run(countDownFn));
      });
    };
    subscribeToInterval();

    // it emits on every mousemove/keypress/touchend event
    const moveOrType$ = merge(
      fromEvent(document, 'mousemove'),
      fromEvent(document, 'keypress'),
      fromEvent(document, 'touchend'),
      fromEvent(document, 'click')
    );
    moveOrTypeSubs = moveOrType$.subscribe(() => {
      intervalSubs.unsubscribe();
      this.countDown = Math.round(this.securityService.ttl / 1000);
      if (this.countDown === 0) { // when killSession ==> securityService.ttl === 0
        afterMouseMoveOrTypeSubs.unsubscribe();
      }
    });

    // it emits values 1s after the user stops moving the mouse or typing
    // https://rxjs.dev/api/operators/debounceTime
    const afterMouseMoveOrType$ = moveOrType$.pipe(debounceTime(1000));
    afterMouseMoveOrTypeSubs = afterMouseMoveOrType$.subscribe(() => {
      this.countDown = Math.round(this.securityService.ttl / 1000) - 1;
      subscribeToInterval();
    });
  }

  /**
   * Logs the app is up and running and the configuration
   */
  private _logMessages() {
    const styles1 = ['background: AliceBlue; font-weight: bold'].join(';');
    const styles2 = ['background: AliceBlue'].join(';');
    const styles3 = ['background: mediumseagreen', 'color: white', 'padding: 5px 20px', 'text-align: center'].join(';');
    console.log(`%c The app is running with this configuration: %c ${JSON.stringify(this.configService.config)}`, styles1, styles2);
    console.log(`%c Congrats! Your Darwin app is up and running`, styles3);
  }
}
