import { TestBed, async, tick, fakeAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AppComponent } from './app.component';
import { SecurityTestingModule, SecurityService } from '@ng-darwin/security';
import { LoggerTestingModule } from '@ng-darwin/logger';
import { ConfigTestingModule } from '@ng-darwin/config';
import { TranslateModule } from '@ngx-translate/core';

/**********************************************************************
* IMPORTANT!!
* You can delete all this tests when you can start developing your app
***********************************************************************/

describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        TranslateModule.forRoot(),
        HttpClientTestingModule,
        ConfigTestingModule.forRoot({
          appKey: 'appKey_mock',
          appName: 'appName_mock',
          app: {
            docRoutes: {
              dw: 'dw_url_mock',
              jsonServer: 'jsonServer_url_mock',
              ng: 'ng_url_mock',
              ngCli: 'ngCli_url_mock'
            }
          }
        }),
        SecurityTestingModule,
        LoggerTestingModule
      ],
      declarations: [
        AppComponent
      ],
    }).compileComponents();
  }));

  let fixture: any;
  let app: any;
  let httpTestingController: any;
  let securityService: SecurityService;

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    app = fixture.debugElement.componentInstance;
    httpTestingController = TestBed.get(HttpTestingController);
    securityService = TestBed.get(SecurityService);
  });

  it('should create the app', () => {
    expect(app).toBeTruthy();
  });

  it('should restart the count down when there is a mouse event', fakeAsync(() => {
    const msTos = (ms: number) => ms/1000;
    fixture.detectChanges();  // onInit()
    tick(); // flush the component's setTimeout()
    expect(app.countDown).toBe(msTos(securityService.ttl));
    tick(securityService.ttl * 1/4); // a quarter of the ttl time goes...
    expect(app.countDown).toBe(msTos(securityService.ttl * 3/4)); // three quarters of ttl time left
    document.dispatchEvent(new MouseEvent('mousemove'));
    expect(app.countDown).toBe(msTos(securityService.ttl)); // countdown starts again
    tick(securityService.ttl); // all ttl time goes...
    expect(app.countDown).toBe(0); // the countdown is over
    tick(1000); // needed to there are no pending timers
  }));

  it('should response as expected when postRequestThroughLoggerService method is called',  fakeAsync(() => {
    fixture.detectChanges();  // onInit()
    app.postRequestThroughLoggerService();
    tick();
    expect(app.response).toBe('Log enviado a fake Data Base. Se ha creado un nuevo registro en el fichero db.json');
    tick(securityService.ttl + 1000); // needed to there are no pending timers
  }));

  it('should response as expected when getRequestThroughHttpClient method is called', () => {
    const resData = { appKey:'APPKEY', log:'my message', component:'mycomponent' };
    fixture.detectChanges();  // onInit()
    app.getRequestThroughHttpClient();
    const req = httpTestingController.expectOne('http://localhost:3000/api/logger/logs');
    req.flush(resData);
    expect(app.response).toEqual(resData);
    httpTestingController.verify();
  });

  it('should response as expected when getRequestThroughHttpBareClient method is called', () => {
    const resData = 'ok';
    fixture.detectChanges();  // onInit()
    app.getRequestThroughHttpBareClient();
    const req = httpTestingController.expectOne('/api/alive');
    req.flush(resData);
    expect(app.response).toBe(resData);
    httpTestingController.verify();
  });

  it('should call killSession on SecurityService when closeSession method is called', fakeAsync(() => {
    const killSessionSpy = spyOn(securityService, 'killSession').and.callThrough();
    fixture.detectChanges();  // onInit()
    tick();
    expect(app.countDown).toBe(120);
    app.closeSession();
    document.dispatchEvent(new MouseEvent('click'));
    expect(killSessionSpy).toHaveBeenCalled();
    expect(app.countDown).toBe(0);
  }));
});
