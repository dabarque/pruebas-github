import { LogLevel } from '@darwin/config';

export const environment = {
  production: true,
  configLogLevel: LogLevel.ERROR
};