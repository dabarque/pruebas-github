import { browser, by, element } from 'protractor';

export class AppPage {
  navigateTo() {
    return browser.get(browser.baseUrl + '?token=fake_token') as Promise<any>;
  }

  getTitleText() {
    return element(by.css('app-root h1')).getText() as Promise<string>;
  }

  clickOnHttpClientButton() {
    return element(by.id('btnHttpClient')).click();
  }

  getTextResponseBox() {
    return element(by.id('response')).getText();
  }
}
