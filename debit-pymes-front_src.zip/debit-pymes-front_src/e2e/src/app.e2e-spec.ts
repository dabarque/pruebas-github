import { AppPage } from './app.po';
import { browser, logging } from 'protractor';
import db from '../../api/db.json';

describe('workspace-project App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should display welcome message', async () => {
    await page.navigateTo();
    expect(await page.getTitleText()).toEqual('¡Bienvenido a Darwin para Angular!');
  });

  it('should display the same logs as those stored in the fake data base when HTTPCLIENT REQUEST button is clicked', async () => {
    await page.navigateTo();
    await page.clickOnHttpClientButton();
    const response = await page.getTextResponseBox();
    const logsFromDB = JSON.stringify(db.logs);
    expect(response.replace(/\s+/g, '')).toEqual(logsFromDB.replace(/\s+/g, ''));
  });

  afterEach(async () => {
    // Assert that there are no errors emitted from the browser
    const logs = await browser.manage().logs().get(logging.Type.BROWSER);
    expect(logs).not.toContain(jasmine.objectContaining({
      level: logging.Level.SEVERE,
    } as logging.Entry));
  });
});
